/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package 九九乘法表;

/**
 *
 * @author Administrator
 */
public class 九九乘法表 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int a[][] = new int[10][10];
    for(int i=1;i<=9;i++){
      for(int j=1;j<=i;j++){
        a[i][j] = i*j;
        System.out.print(i+"*"+j+"="+a[i]
[j]+"\t");
    }
    System.out.println("");
   }

    }
    
}
