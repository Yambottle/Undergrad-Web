
package al_mart;

public class Al_Mart {

    public static void main(String[] args) {
        Welcome w= new Welcome();
        
    }
    
}
