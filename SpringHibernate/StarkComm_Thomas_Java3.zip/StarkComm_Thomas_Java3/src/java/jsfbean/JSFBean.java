/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsfbean;

import hibernate.Employee;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author user
 */
@ManagedBean
@RequestScoped
public class JSFBean {

     private int id;
     private String fullname;
     private String apartment;
     private String password;
     private String seQues;
     private String answer;
     
    public JSFBean() {
    }

    public String saveEmp(){
        Employee emp = new Employee();
        ApplicationContext ac = new ClassPathXmlApplicationContext("beandao/Spring-Config.xml");
        JSFBean helper = (JSFBean) ac.getBean("beanDao");
        emp.setId(getId());
        emp.setFullname(getFullname());
        emp.setApartment(getApartment());
        emp.setPassword(getPassword());
        emp.setSeQues(getSeQues());
        emp.setAnswer(getAnswer());
        String msg = helper.saveEmp();
       
        return msg;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSeQues() {
        return seQues;
    }

    public void setSeQues(String seQues) {
        this.seQues = seQues;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    } 
    
}
