/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beandao;

import hibernate.Employee;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author user
 */
public class BeanDao {
    
    SessionFactory sessionFactory;
    
    public BeanDao(){
        Configuration configuration = new Configuration().configure();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    @Transactional(propagation = Propagation.REQUIRED,readOnly = false,isolation = Isolation.DEFAULT)
    public String bookTiket(Employee emp) {
        
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(emp);
        tx.commit();
        
        return "home";
    }
    
    
    
}
