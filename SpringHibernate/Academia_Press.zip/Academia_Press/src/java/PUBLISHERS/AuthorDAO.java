/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PUBLISHERS;

import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author user
 */
public class AuthorDAO {
    
    private static SessionFactory sessionFactory;
    String b="Success";
    
    public AuthorDAO(){
        Configuration configuration = new Configuration().configure(); 
    }
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void setSessionFactory(SessionFactory sessionFactory) {
        AuthorDAO.sessionFactory = sessionFactory;
    }
    
    
    
    public String insertAuthor(Author a)
    {
        Session session=sessionFactory.openSession();
        Transaction tx=null;
         try
          {
            tx= session.beginTransaction();
           Serializable objID=session.save(a);
            tx.commit();
         }
         catch (Exception e)
         {
            
            if (tx != null) {
                  tx.rollback();
                  
             }
             b="index";
            System.out.println(e.getMessage());
        }
        return b;
        }
}
