/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author student
 */
public class ShowRecords extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            int p1 = 340;
            int p2 = 432;
            int p3 = 346;
            int p4 = 445;
            int p5 = 456;
            int total_price=0;
            
            HttpSession session =request.getSession();
            if(session.getAttribute("price")==null){
                String param_name= null;
                Enumeration name;
                name=request.getParameterNames();
                while(name.hasMoreElements()){
                    param_name=name.nextElement().toString();
                    switch(param_name){
                        case "c1": total_price+=p1;break;
                        case "c2": total_price+=p2;break;
                        case "c3": total_price+=p3;break;
                        case "c4": total_price+=p4;break;
                        case "c5": total_price+=p5;break;
                    }
                }
                session.setAttribute("price", total_price);
            }
            out.println("Welcome "+session.getAttribute("name")+"<br>");
            out.println("Your bill total price is $ "+session.getAttribute("price")+"<br>");
            out.println("<a href=\"index.html\">Go back to the homepage</a>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
