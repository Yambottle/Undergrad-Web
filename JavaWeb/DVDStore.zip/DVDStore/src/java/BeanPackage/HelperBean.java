/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BeanPackage;

import Hibernate.Customer;
import Hibernate.DVDHibernateUtil;
import Hibernate.Movie;
import Hibernate.Orderinfor;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Administrator
 */
public class HelperBean {
    
    SessionFactory sf =null ;
    
    public void HelperBean(){
        sf = new DVDHibernateUtil().getSessionFactory();
    }
    
    public String userSignup(Customer customer){
        String msg = null;
        Session session = sf.openSession();
        session.beginTransaction();
        String cuname = customer.getUsername().toString();
        Query  query = session.createQuery("FROM Hibernate.Customer");
        List<Customer> customerList = query.list();
        for(Customer c :customerList){
            if(c.getUsername().equals(cuname)){
                msg = "Username Presented";
                break;
            }
            msg = cuname;
        }
        if(msg.equals(cuname)){
        session.save(customer);
        session.getTransaction().commit();
        session.close();
        sf.close();
        }
        
        return msg;
    }
    
    public String checkLogin(String username,String password){
        String msg = null;
        Session session = sf.openSession();
        session.beginTransaction();
        Query query = session.createQuery("SELECT password Customer WHERE username='"+username+"'");
        String pwd =query.getQueryString();
        if(password.equals(pwd)){
            msg=username;
        }else{
            msg="Password Incorrect.";
        }
        session.getTransaction().commit();
        session.close();
        sf.close();
        
        return msg;
    }
    
    public List<Movie> getMovie(){
        Session session = sf.openSession();
        session.beginTransaction();
        Query  query = session.createQuery("FROM Hibernate.Movie");
        List<Movie> movieList = query.list();
        session.getTransaction().commit();
        session.close();
        sf.close();
        return movieList;
    }
    
    public List<Movie> getChooseMovie(String id){
        Session session = sf.openSession();
        session.beginTransaction();
        Query  query = session.createQuery("FROM Hibernate.Movie WHERE id="+id);
        List<Movie> movieList = query.list();
        session.getTransaction().commit();
        session.close();
        sf.close();
        
        return movieList;
    }
    
    public String insertOrder(Orderinfor order){
        String msg = null;
        try{
        Session session = sf.openSession();
        session.beginTransaction();
        session.save(order);
        session.getTransaction().commit();
        session.close();
        sf.close();
        
        msg="Order successed to create";
        }catch(HibernateException he){
            he.toString();
            msg="Order failed to create.";
        }
        return msg;
    }
    
    public List<Orderinfor> showOrder(String username){
        Session session = sf.openSession();
        session.beginTransaction();
        Query  query = session.createQuery("FROM Hibernate.Orderinfor WHERE username='"+username+"'");
        List<Orderinfor> orderList = query.list();
        session.getTransaction().commit();
        session.close();
        sf.close();
        
        return orderList;
    }
    
    public List<Movie> getMovieByABC(String capital){
        Session session = sf.openSession();
        session.beginTransaction();
        Criteria criteria = session.createCriteria(Movie.class).add(Restrictions.like("mname", capital+"%"));
        List<Movie> movieList = criteria.list();
        session.getTransaction().commit();
        session.close();
        sf.close();
        return movieList;
    }
    
    public List<Movie> getMovieByCate(String category){
        Session session = sf.openSession();
        session.beginTransaction();
        Criteria criteria = session.createCriteria(Movie.class).add(Restrictions.like("category", category));
        List<Movie> movieList = criteria.list();
        session.getTransaction().commit();
        session.close();
        sf.close();
        return movieList;
    }
}
