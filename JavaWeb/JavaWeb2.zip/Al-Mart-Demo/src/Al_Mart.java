import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JTabbedPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;


public class Al_Mart {

	private JFrame frmAlnayeshMartmanager;
	/**
	 * @wbp.nonvisual location=57,7
	 */
	private final JLabel label = DefaultComponentFactory.getInstance().createTitle("New JGoodies title");
	private JTextField t_addid;
	private JTextField t_addgender;
	private JTextField t_addname;
	private JTextField t_addpos;
	private JTextField t_addpho;
	private JTextField t_upid;
	private JTextField t_upgen;
	private JTextField t_upname;
	private JTextField t_uppos;
	private JTextField t_uppho;
	private JTextField t_sid;
	private JTextField t_sgen;
	private JTextField t_sname;
	private JTextField t_spos;
	private JTextField t_spho;
	private JTextField t_did;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Al_Mart window = new Al_Mart();
					window.frmAlnayeshMartmanager.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Al_Mart() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAlnayeshMartmanager = new JFrame();
		frmAlnayeshMartmanager.setTitle("Al-Nayesh Mart:Manager");
		frmAlnayeshMartmanager.setBounds(100, 100, 593, 370);
		frmAlnayeshMartmanager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAlnayeshMartmanager.getContentPane().setLayout(null);
		
		JTabbedPane tp_emp = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_emp.setToolTipText("Employee");
		tp_emp.setBounds(10, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_emp);
		
		JTabbedPane tp_intro = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_intro.setBounds(83, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_intro);
		
		JTabbedPane tp_sale = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_sale.setBounds(154, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_sale);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 41, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton b_add = new JButton("Add");
		b_add.setBounds(211, 94, 51, 23);
		panel.add(b_add);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setBounds(10, 10, 54, 15);
		panel.add(lblId);
		
		JLabel label_1 = new JLabel("Name:");
		label_1.setBounds(10, 36, 54, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Position:");
		label_2.setBounds(10, 61, 54, 15);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Gender:");
		label_3.setBounds(125, 10, 54, 15);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Phone Number:");
		label_4.setBounds(10, 85, 89, 15);
		panel.add(label_4);
		
		t_addid = new JTextField();
		t_addid.setBounds(33, 7, 66, 21);
		panel.add(t_addid);
		t_addid.setColumns(10);
		
		t_addgender = new JTextField();
		t_addgender.setBounds(172, 7, 66, 21);
		panel.add(t_addgender);
		t_addgender.setColumns(10);
		
		t_addname = new JTextField();
		t_addname.setBounds(43, 33, 97, 21);
		panel.add(t_addname);
		t_addname.setColumns(10);
		
		t_addpos = new JTextField();
		t_addpos.setColumns(10);
		t_addpos.setBounds(67, 58, 97, 21);
		panel.add(t_addpos);
		
		t_addpho = new JTextField();
		t_addpho.setColumns(10);
		t_addpho.setBounds(94, 82, 97, 21);
		panel.add(t_addpho);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBounds(295, 180, 272, 64);
		frmAlnayeshMartmanager.getContentPane().add(panel_3);
		
		JButton button_1 = new JButton("Delete");
		button_1.setBounds(193, 20, 69, 23);
		panel_3.add(button_1);
		
		JLabel label_15 = new JLabel("ID:");
		label_15.setBounds(10, 24, 54, 15);
		panel_3.add(label_15);
		
		t_did = new JTextField();
		t_did.setColumns(10);
		t_did.setBounds(39, 21, 66, 21);
		panel_3.add(t_did);
		
		JLabel lblNewLabel = new JLabel("Employee Information Modifiy");
		lblNewLabel.setFont(new Font("Sakkal Majalla", Font.BOLD, 25));
		lblNewLabel.setBounds(305, 259, 262, 44);
		frmAlnayeshMartmanager.getContentPane().add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(10, 178, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel_1);
		
		JButton button = new JButton("Update");
		button.setBounds(193, 94, 69, 23);
		panel_1.add(button);
		
		JLabel label_5 = new JLabel("ID:");
		label_5.setBounds(10, 10, 54, 15);
		panel_1.add(label_5);
		
		JLabel label_6 = new JLabel("Name:");
		label_6.setBounds(10, 36, 54, 15);
		panel_1.add(label_6);
		
		JLabel label_7 = new JLabel("Position:");
		label_7.setBounds(10, 61, 54, 15);
		panel_1.add(label_7);
		
		JLabel label_8 = new JLabel("Gender:");
		label_8.setBounds(125, 10, 54, 15);
		panel_1.add(label_8);
		
		JLabel label_9 = new JLabel("Phone Number:");
		label_9.setBounds(10, 85, 89, 15);
		panel_1.add(label_9);
		
		t_upid = new JTextField();
		t_upid.setColumns(10);
		t_upid.setBounds(33, 7, 66, 21);
		panel_1.add(t_upid);
		
		t_upgen = new JTextField();
		t_upgen.setColumns(10);
		t_upgen.setBounds(172, 7, 66, 21);
		panel_1.add(t_upgen);
		
		t_upname = new JTextField();
		t_upname.setColumns(10);
		t_upname.setBounds(43, 33, 97, 21);
		panel_1.add(t_upname);
		
		t_uppos = new JTextField();
		t_uppos.setColumns(10);
		t_uppos.setBounds(67, 58, 97, 21);
		panel_1.add(t_uppos);
		
		t_uppho = new JTextField();
		t_uppho.setColumns(10);
		t_uppho.setBounds(94, 82, 97, 21);
		panel_1.add(t_uppho);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(295, 41, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel_2);
		
		JButton button_2 = new JButton("Search");
		button_2.setBounds(193, 94, 69, 23);
		panel_2.add(button_2);
		
		JLabel label_10 = new JLabel("ID:");
		label_10.setBounds(10, 10, 54, 15);
		panel_2.add(label_10);
		
		JLabel label_11 = new JLabel("Name:");
		label_11.setBounds(10, 36, 54, 15);
		panel_2.add(label_11);
		
		JLabel label_12 = new JLabel("Position:");
		label_12.setBounds(10, 61, 54, 15);
		panel_2.add(label_12);
		
		JLabel label_13 = new JLabel("Gender:");
		label_13.setBounds(125, 10, 54, 15);
		panel_2.add(label_13);
		
		JLabel label_14 = new JLabel("Phone Number:");
		label_14.setBounds(10, 85, 89, 15);
		panel_2.add(label_14);
		
		t_sid = new JTextField();
		t_sid.setColumns(10);
		t_sid.setBounds(33, 7, 66, 21);
		panel_2.add(t_sid);
		
		t_sgen = new JTextField();
		t_sgen.setColumns(10);
		t_sgen.setBounds(172, 7, 66, 21);
		panel_2.add(t_sgen);
		
		t_sname = new JTextField();
		t_sname.setColumns(10);
		t_sname.setBounds(43, 33, 97, 21);
		panel_2.add(t_sname);
		
		t_spos = new JTextField();
		t_spos.setColumns(10);
		t_spos.setBounds(67, 58, 97, 21);
		panel_2.add(t_spos);
		
		t_spho = new JTextField();
		t_spho.setColumns(10);
		t_spho.setBounds(94, 82, 89, 21);
		panel_2.add(t_spho);
	}
}
