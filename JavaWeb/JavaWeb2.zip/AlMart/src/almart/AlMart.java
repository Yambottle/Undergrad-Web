
package almart;

import java.awt.Font;
import javax.swing.*;
import java.lang.Thread;

class Welcome extends JFrame implements Runnable{
    public void wel(){
        setTitle("Al-Nayesh");
        setBounds(100, 100, 450, 300);
        setLayout(null);
        setVisible(true);
        JLabel l = new JLabel("Welcome to Al-Nayesh Mart!");
	l.setFont(new Font("Sakkal Majalla", Font.BOLD, 38));
	l.setBounds(30, 173, 376, 79);
        //l.setIcon(null);图标图片
        //l.setHorizontalTextPosition();
        add(l);
        
    }
    public void run(){
        try{        
            Thread.sleep(7000);
            setVisible(false);
            Choice c =new Choice();
            c.cho();
        }catch(Exception e){
            System.out.println("Error: "+e.toString());
        }
        
    }
} 

class Choice{
    public void cho(){ 
                JFrame frame = new JFrame();
		frame.setBounds(100, 100, 422, 358);
                frame.setTitle("Al-Nayesh:Log");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
                frame.setVisible(true);
		
		JLabel l = new JLabel("Please Chose Your Identity : ");
		l.setFont(new Font("Sakkal Majalla", Font.BOLD, 30));
		l.setBounds(25, 156, 376, 51);
		frame.getContentPane().add(l);
		
		JLabel label_1 = new JLabel("Please Enter Your ID and Password :");
		label_1.setFont(new Font("Sakkal Majalla", Font.BOLD, 30));
		label_1.setBounds(25, 10, 376, 51);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("ID Number :");
		label_2.setFont(new Font("Sakkal Majalla", Font.BOLD, 24));
		label_2.setBounds(66, 74, 98, 35);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("Password :");
		label_3.setFont(new Font("Sakkal Majalla", Font.BOLD, 24));
		label_3.setBounds(66, 108, 98, 35);
		frame.getContentPane().add(label_3);
		
		JTextField textField = new JTextField();
		textField.setBounds(196, 81, 128, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(196, 117, 128, 21);
		frame.getContentPane().add(textField_1);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Mnanger");
		rdbtnNewRadioButton.setFont(new Font("Sakkal Majalla", Font.PLAIN, 24));
		rdbtnNewRadioButton.setBounds(66, 215, 121, 23);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton radioButton = new JRadioButton("Employee");
		radioButton.setFont(new Font("Sakkal Majalla", Font.PLAIN, 24));
		radioButton.setBounds(231, 215, 121, 23);
		frame.getContentPane().add(radioButton);
		
		JButton btnNewButton = new JButton("Log in");
		btnNewButton.setBounds(66, 259, 93, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("Exist");
		button.setBounds(245, 259, 93, 23);
		frame.getContentPane().add(button);
        
        ButtonGroup bg =new ButtonGroup();
        bg.add(radioButton);
        bg.add(rdbtnNewRadioButton);
    }    
    //两个Text/两个Radio/两个Button
}

class Manager{
    public void man(){
                JFrame frmAlnayeshMartmanager = new JFrame();
		frmAlnayeshMartmanager.setTitle("Al-Nayesh Mart:Manager");
		frmAlnayeshMartmanager.setBounds(100, 100, 593, 370);
                frmAlnayeshMartmanager.setVisible(true);
		frmAlnayeshMartmanager.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAlnayeshMartmanager.getContentPane().setLayout(null);
		//Emp
		JTabbedPane tp_emp = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_emp.setToolTipText("Employee");
		tp_emp.setBounds(10, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_emp);
		
		//add
		JPanel panel = new JPanel();
		panel.setBounds(10, 41, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton b_add = new JButton("Add");
		b_add.setBounds(211, 94, 51, 23);
		panel.add(b_add);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setBounds(10, 10, 54, 15);
		panel.add(lblId);
		
		JLabel label_1 = new JLabel("Name:");
		label_1.setBounds(10, 36, 54, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Position:");
		label_2.setBounds(10, 61, 54, 15);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Gender:");
		label_3.setBounds(125, 10, 54, 15);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Phone Number:");
		label_4.setBounds(10, 85, 89, 15);
		panel.add(label_4);
		
                JTextField t_addid = new JTextField();
		t_addid.setBounds(33, 7, 66, 21);
		panel.add(t_addid);
		t_addid.setColumns(10);
		
		JTextField t_addgender = new JTextField();
		t_addgender.setBounds(172, 7, 66, 21);
		panel.add(t_addgender);
		t_addgender.setColumns(10);
		
		JTextField t_addname = new JTextField();
		t_addname.setBounds(43, 33, 97, 21);
		panel.add(t_addname);
		t_addname.setColumns(10);
		
		JTextField t_addpos = new JTextField();
		t_addpos.setColumns(10);
		t_addpos.setBounds(67, 58, 97, 21);
		panel.add(t_addpos);
		
		JTextField t_addpho = new JTextField();
		t_addpho.setColumns(10);
		t_addpho.setBounds(94, 82, 97, 21);
		panel.add(t_addpho);
                
		//delete
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBounds(295, 180, 272, 64);
		frmAlnayeshMartmanager.getContentPane().add(panel_3);
		
		JButton button_1 = new JButton("Delete");
		button_1.setBounds(193, 20, 69, 23);
		panel_3.add(button_1);
		
		JLabel label_15 = new JLabel("ID:");
		label_15.setBounds(10, 24, 54, 15);
		panel_3.add(label_15);
		
		JTextField t_did = new JTextField();
		t_did.setColumns(10);
		t_did.setBounds(39, 21, 66, 21);
		panel_3.add(t_did);
                
		//update
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(10, 178, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel_1);
		
		JButton button = new JButton("Update");
		button.setBounds(193, 94, 69, 23);
		panel_1.add(button);
		
		JLabel label_5 = new JLabel("ID:");
		label_5.setBounds(10, 10, 54, 15);
		panel_1.add(label_5);
		
		JLabel label_6 = new JLabel("Name:");
		label_6.setBounds(10, 36, 54, 15);
		panel_1.add(label_6);
		
		JLabel label_7 = new JLabel("Position:");
		label_7.setBounds(10, 61, 54, 15);
		panel_1.add(label_7);
		
		JLabel label_8 = new JLabel("Gender:");
		label_8.setBounds(125, 10, 54, 15);
		panel_1.add(label_8);
		
		JLabel label_9 = new JLabel("Phone Number:");
		label_9.setBounds(10, 85, 89, 15);
		panel_1.add(label_9);
		
		JTextField t_upid = new JTextField();
		t_upid.setColumns(10);
		t_upid.setBounds(33, 7, 66, 21);
		panel_1.add(t_upid);
		
		JTextField t_upgen = new JTextField();
		t_upgen.setColumns(10);
		t_upgen.setBounds(172, 7, 66, 21);
		panel_1.add(t_upgen);
		
		JTextField t_upname = new JTextField();
		t_upname.setColumns(10);
		t_upname.setBounds(43, 33, 97, 21);
		panel_1.add(t_upname);
		
		JTextField t_uppos = new JTextField();
		t_uppos.setColumns(10);
		t_uppos.setBounds(67, 58, 97, 21);
		panel_1.add(t_uppos);
		
		JTextField t_uppho = new JTextField();
		t_uppho.setColumns(10);
		t_uppho.setBounds(94, 82, 97, 21);
		panel_1.add(t_uppho);
                
		//serch
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(295, 41, 272, 127);
		frmAlnayeshMartmanager.getContentPane().add(panel_2);
		
		JButton button_2 = new JButton("Search");
		button_2.setBounds(193, 94, 69, 23);
		panel_2.add(button_2);
		
		JLabel label_10 = new JLabel("ID:");
		label_10.setBounds(10, 10, 54, 15);
		panel_2.add(label_10);
		
		JLabel label_11 = new JLabel("Name:");
		label_11.setBounds(10, 36, 54, 15);
		panel_2.add(label_11);
		
		JLabel label_12 = new JLabel("Position:");
		label_12.setBounds(10, 61, 54, 15);
		panel_2.add(label_12);
		
		JLabel label_13 = new JLabel("Gender:");
		label_13.setBounds(125, 10, 54, 15);
		panel_2.add(label_13);
		
		JLabel label_14 = new JLabel("Phone Number:");
		label_14.setBounds(10, 85, 89, 15);
		panel_2.add(label_14);
		
		JTextField t_sid = new JTextField();
		t_sid.setColumns(10);
		t_sid.setBounds(33, 7, 66, 21);
		panel_2.add(t_sid);
		
		JTextField t_sgen = new JTextField();
		t_sgen.setColumns(10);
		t_sgen.setBounds(172, 7, 66, 21);
		panel_2.add(t_sgen);
		
		JTextField t_sname = new JTextField();
		t_sname.setColumns(10);
		t_sname.setBounds(43, 33, 97, 21);
		panel_2.add(t_sname);
		
		JTextField t_spos = new JTextField();
		t_spos.setColumns(10);
		t_spos.setBounds(67, 58, 97, 21);
		panel_2.add(t_spos);
		
		JTextField t_spho = new JTextField();
		t_spho.setColumns(10);
		t_spho.setBounds(94, 82, 89, 21);
		panel_2.add(t_spho);
                
                //Info
		JLabel lblNewLabel = new JLabel("Employee Information Modifiy");
		lblNewLabel.setFont(new Font("Sakkal Majalla", Font.BOLD, 25));
		lblNewLabel.setBounds(305, 259, 262, 44);
		frmAlnayeshMartmanager.getContentPane().add(lblNewLabel);
                
                //Inventory
		JTabbedPane tp_intro = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_intro.setBounds(83, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_intro);
                
		//Sale
		JTabbedPane tp_sale = new JTabbedPane(JTabbedPane.BOTTOM);
		tp_sale.setBounds(154, 10, 63, 21);
		frmAlnayeshMartmanager.getContentPane().add(tp_sale);
    }
}

class Employee{
    public void emp(){
        
    }
}

public class AlMart {

    public static void main(String[] args) {
//           //welcome
//           Welcome w= new Welcome();
//           w.wel();
//           Thread t1 =new Thread(w);
//           //choice
//           t1.start();
       Manager m =new Manager();
       m.man();
           
           
    }
    
}
