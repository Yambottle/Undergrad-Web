/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

/**
 *
 * @author NIIT
 */
public class Football implements Player{
    public Football(){}
    
    private int shirtnum;
    
    public Football(int shirtnum){
        this.shirtnum = shirtnum; 
    }
    
    private String football;

    public void setFootball(String football) {
        this.football = football;
    }
    
    private FootballBoots boots;

    public void setBoots(FootballBoots boots) {
        this.boots = boots;
    }
    
    @Override
    public void play() {
        System.out.println("I am playing with "+football+" football.\nShirtnum is "+shirtnum);
        boots.wearBoot();
    }
    
}
