/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Administrator
 */
public class FileWriterUtil {
    
    private static String DefaultFileDir = getRelativeBasePath();

    /**
     * 设置输出文件的相对目录
     * @param filePath 相对于项目根目录的路径，直接以跟目录下的某文件夹名开头，不以“\”开头
     */
    public void setFileRelativePath(String filePath) {
        DefaultFileDir += "\\"+filePath+"\\";
    }
    
    /**
     * 设置输出文件的绝对目录
     * @param filePath 目录的绝对路径
     */
    public void setFileAbsolutePath(String filePath) {
        DefaultFileDir = filePath;
    }

    /**
     * 添加内容到文件结尾
     *
     * @param filePath 文件绝对地址
     * @param content 要添加的内容
     * @throws FileNotFoundException
     */
    public void addContentToFile(String filePath, String content) throws FileNotFoundException {
        appendToFile(filePath, content);
    }

    /**
     * 添加新行到文件结尾（默认生成 /[fileName].txt）
     *
     * @param fileName 文件名
     * @param content 要添加的内容
     * @throws FileNotFoundException
     */
    public void addNewLineToFileName(String fileName, String content) throws FileNotFoundException {
        appendToFile(DefaultFileDir + fileName + ".txt", content + "\r\n");
    }

    /**
     * 内部方法 追加文件基本方法：使用FileWriter
     *
     * @param fileName
     * @param content
     */
    private static void appendToFile(String fileName, String content) {
        FileWriter writer = null;
        try {
            // 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件     
            writer = new FileWriter(fileName, true);
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 获取项目相对根目录
     *
     * @return
     */
    public static String getRelativeBasePath() {
        String relativePath = System.getProperty("user.dir");
        return relativePath;
    }

    public static void main(String[] args) throws FileNotFoundException {
        System.out.println(getRelativeBasePath());
    }
}
