/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import AOP.HelloInterface;
import AOP.ValidateUser;
import User.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import service.HelloService;

/**
 *
 * @author user
 */
@Controller 
@RequestMapping(value = "/main.htm")
public class HelloController {
    private HelloService helloService ;
    
    @RequestMapping(method = RequestMethod.GET)
    public String showView(ModelMap model)
    {
        User user = new User();
        model.addAttribute("User",user);
        return "main";
    }
    
    @RequestMapping(method = RequestMethod.POST)
    public String processView(@ModelAttribute(value = "User") User user,ModelMap model){
        String message ;
        ApplicationContext ac = new ClassPathXmlApplicationContext("AOP/Spring-Config.xml");
        HelloInterface hi =(HelloInterface) ac.getBean("helloProxy");
        String uname = user.getName();
        
        if(ValidateUser.msg1.equals("User Authenticated.")){
            message="Hello!"+uname;
        }else{
            message="Invalid User";
            model.addAttribute("welcomemessage",message);
        }
        return "success";
    }

    public void setHelloService(HelloService helloService) {
        this.helloService = helloService;
    }
    
}
