/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithm;

/**
 *
 * @author Lenovo
 */
public class Two {
    public int a;
    public int b;

    public Two(int a, int b) {
        this.a = a;
        this.b = b;
    }
    
    public String toString(){
        return "a: "+a +"  b:"+b;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    
    
    
}
