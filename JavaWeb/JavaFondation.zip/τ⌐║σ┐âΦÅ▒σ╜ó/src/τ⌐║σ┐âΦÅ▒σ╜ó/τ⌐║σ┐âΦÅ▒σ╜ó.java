/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package 空心菱形;

/**
 *
 * @author Administrator
 */
public class 空心菱形 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         int i,j,row;
        for(row=5;row>=1;row--)
        {
          for(i=1;i<=row;i++)
          {System.out.print(" ");
          }
          for(j=1;j<=6-row;j++)
          {   if(j==1||j==6-row)
          {System.out.print("* ");}
              else
          {System.out.print("  ");}
          }
          System.out.println();
        }
        
        int k;
        for(k=1;k<=6;k++)
        {     if(k==1||k==6)
        {System.out.print("* ");}
              else
        {System.out.print("  ");}
        }
        System.out.println();

         int m,n,row2;
        for(row2=1;row2<=5;row2++)
        {
          for(m=1;m<=row2;m++)
          {System.out.print(" ");
          }
          for(n=1;n<=6-row2;n++)
          {   if(n==1||n==6-row2)
          {System.out.print("* ");}
              else
          {System.out.print("  ");}
          }
          System.out.println();
        }
        

    }
    
}
