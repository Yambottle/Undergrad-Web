package PUBLISHERS;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class BeanHelper {
private static Session session;
String b="Success";
public BeanHelper()
    {
        
    }
    public String insertAuthor(Author a)
    {
        session=HibernateUtil.getSessionFactory().openSession();
        Transaction tx=null;
         try
          {
            tx= session.beginTransaction();
           Serializable objID=session.save(a);
            tx.commit();
         }
         catch (Exception e)
         {
            
            if (tx != null) {
                  tx.rollback();
                  
             }
             b="index";
            System.out.println(e.getMessage());
        }
        return b;
        }
    
}