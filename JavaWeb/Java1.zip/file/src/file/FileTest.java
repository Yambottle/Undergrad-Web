

package file;
import java.io.*;
import java.util.Scanner;

public class FileTest {

    public static void main(String[] args) {
             String filename ="C:\\Users\\Administrator\\Desktop\\课堂心得";
         try{
             File f=new File(filename);//类名不能用关键字 = =
             FileInputStream filein=new FileInputStream(filename);//创建输入流
             FileOutputStream fileout = new FileOutputStream("C:\\Users\\Administrator\\Desktop\\1.doc");
             byte[] buffer = new byte[(int)f.length()];
             filein.read(buffer);
             
             fileout.write(buffer);
             filein.close();
             fileout.close();
        }catch(FileNotFoundException e)
        {
            System.err.println("该文件不存在。");   
        } 
         catch(Exception n)
         {
             System.err.println("该文件不可读。"); 
         }

    }
}

