create database webdb
use webdb

create table Student(
RegNo char(10) primary key,
Pwd char(16),
Ename char(10),
Cname nchar(5),
Gender char(5),
BatchCode char(5) foreign key references Batch(BatchCode)
)
select * from student
insert student values('S01','s01','Thomas','����','male','J01')
select pwd from student where regno='S01'


create table Batch(
BatchCode char(5) primary key,
Sdate date,
Edate date,
TID char(10) foreign key references Teacher(TID)
)
select * from batch
insert batch values('J01','2015-11-24','2016-12-24','T01')

create table Teacher(
TID char(10) primary key,
Pwd char(16),
Ename char(10),
Cname nchar(5),
Gender char(5),
)
select * from teacher
insert Teacher values('T01','t01','Tony','����','male')

create table Modules(
MID char(10) primary key,
Mname char(20)
)

create table Question(
QID char(10) primary key,
MID char(10) foreign key references Modules(MID),
TID char(10) foreign key references Teacher(TID),
Descrip char(500),
Ca char(500),
Cb char(500),
Cc char(500),
Cd char(500),
Ans char(5),
QScore int
)

create table ScoreFB(
RegNo char(10),
MID char(10),
TotalScore int,
primary key (RegNo,MID)
)

create table Choice(
RegNo char(10),
QID char(10),
MID char(10),-----------------------------
Cho char(5),
primary key (RegNo,QID,MID)
)



