
package executordemo;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

class Task implements Callable{
    String taskname ;
    public Task(String name){
        taskname=name;
    }
    public String call(){
        System.out.println("The task name is "+taskname+"executed by "+Thread.currentThread().getName());
        return taskname;
    }
}

public class ExecutorDemo {

    public static void main(String[] args) {
        Task t1 =new Task("t1");
        Task t2 =new Task("t2");
        Task t3 =new Task("t3");
        
        ExecutorService threadexecutor1 =Executors.newFixedThreadPool(3);
        ExecutorService threadexecutor2 =Executors.newFixedThreadPool(3);
        System.out.println("Executor started");
        Future<String> f1=threadexecutor1.submit(t1);
        Future<String> f2=threadexecutor2.submit(t2);
        Future<String> f3=threadexecutor2.submit(t3);
        threadexecutor1.shutdown();
        threadexecutor2.shutdown();
        if(threadexecutor2.isShutdown()){
            System.out.println("All tasks completen. The executor is shutting down.");
        }
        
    }
    
}
