/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package service;


public class Rooms {
    private String roomID;
    private String roomType;
    private int noOfRooms;

    public Rooms(){

    }

    /**
     * @return the roomID
     */
    public String getRoomID() {
        return roomID;
    }

    /**
     * @param roomID the roomID to set
     */
    public void setRoomID(String roomID) {
        this.roomID = roomID;
    }

    /**
     * @return the roomType
     */
    public String getRoomType() {
        return roomType;
    }

    /**
     * @param roomType the roomType to set
     */
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    /**
     * @return the noOfRooms
     */
    public int getNoOfRooms() {
        return noOfRooms;
    }

    /**
     * @param noOfRooms the noOfRooms to set
     */
    public void setNoOfRooms(int noOfRooms) {
        this.noOfRooms = noOfRooms;
    }
    
}
