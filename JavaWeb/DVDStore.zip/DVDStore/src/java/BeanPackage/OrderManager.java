/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BeanPackage;

import Hibernate.Orderinfor;
import java.io.Serializable;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Administrator
 */
@ManagedBean
@RequestScoped
public class OrderManager {

    /**
     * Creates a new instance of OrderManager
     */
     private int id;
     private String destination;
     private String agency;
     private Integer price;
     private Serializable delivertime;
     private Serializable arrivaltime;
     private String status;
     private String username;
     private List<Orderinfor> orderList;
    
    public OrderManager() {
    }
    
    public int getId() {
        return this.id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    public String getDestination() {
        return this.destination;
    }
    
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public String getAgency() {
        return this.agency;
    }
    
    public void setAgency(String agency) {
        this.agency = agency;
    }
    public Integer getPrice() {
        return this.price;
    }
    
    public void setPrice(Integer price) {
        this.price = price;
    }
    public Serializable getDelivertime() {
        return this.delivertime;
    }
    
    public void setDelivertime(Serializable delivertime) {
        this.delivertime = delivertime;
    }
    public Serializable getArrivaltime() {
        return this.arrivaltime;
    }
    
    public void setArrivaltime(Serializable arrivaltime) {
        this.arrivaltime = arrivaltime;
    }
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<Orderinfor> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Orderinfor> orderList) {
        this.orderList = orderList;
    }
    
    
    
    public String createOrder(){
        String msg = null;
        Orderinfor order = new Orderinfor();
        order.setDestination(getDestination());
        order.setDelivertime(getDelivertime());
        order.setArrivaltime(getArrivaltime());
        order.setAgency(getAgency());
        order.setPrice(getPrice());
        order.setStatus(getStatus());
        order.setUsername(getUsername());
        
        HelperBean helper = new HelperBean();
        msg=helper.insertOrder(order);
        
        return msg;
    }
    
    public void showOrder(String username){
        HelperBean helper = new HelperBean();
        setOrderList(helper.showOrder(username));
    }
}
