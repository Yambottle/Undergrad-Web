/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import PUBLISHERS.*;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.bean.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.inject.Named;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@RequestScoped
@Named
public class Bean {
private String aid;
     private String aname;
     private String apenname;
     private String gender;
     private Date dob;
     private String address;
     private String contact;
     private String email;
     private String nationality;

public String submit()
{
    Author a=new Author();
    ApplicationContext ac = new ClassPathXmlApplicationContext("PUBLISHERS/Spring-Config.xml");
    AuthorDAO helper = (AuthorDAO) ac.getBean("authorDAO");
        a.setAuthorid(getAid());
        a.setAuthorname(getAname());
        a.setAuthorpenname(getApenname());
        a.setContactnumber(getContact());
        a.setAddress(getAddress());
        a.setDob(getDob());
        a.setEmailid(getEmail());
        a.setGender(getGender());
        a.setNationality(getNationality());
        String msg = helper.insertAuthor(a);
        return msg;   
}
 public void validateEmail(FacesContext fc, UIComponent c, Object value)throws ValidatorException
    {
        String emailID= (String)value;

        Pattern mask = null;
        mask = Pattern.compile(".+@.+\\.[a-z]+");
       Matcher matcher = mask.matcher(emailID);
        if (!matcher.matches())
         {
           FacesMessage message = new FacesMessage();
           message.setSummary("You must enter an e-mail address in the format, user@serviceprovider.domain");
           throw new ValidatorException(message);
        }
    }
    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public String getApenname() {
        return apenname;
    }

    public void setApenname(String apenname) {
        this.apenname = apenname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
    /**
     * Creates a new instance of Bean
     */
    public Bean() {
    }
    
}
