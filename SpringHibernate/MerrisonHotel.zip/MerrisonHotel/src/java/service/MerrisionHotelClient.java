/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MerrisionHotelClient {
public static void main(String s[]){
        ApplicationContext ac= new ClassPathXmlApplicationContext("service/Spring-Config.xml");
        Customer cust=(Customer)ac.getBean("CustomerBean");
        System.out.println("The Customer Details are:");
        System.out.println("First Name: "+cust.getFirstName());
        System.out.println("First Name: "+cust.getLastName());
        System.out.println("First Name: "+cust.getAddress());
        System.out.println("First Name: "+cust.getPhoneNumber());
    }
}
