
package al_nayesh;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Man extends javax.swing.JFrame {
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    public void initComponents() {
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();//empid
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();//empname
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();//gender
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();//pos
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();//phone
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();//pro_id
        jLabel17 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();//pro_name
        jLabel18 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();//price
        jLabel19 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton8 = new javax.swing.JButton();
        jTextField10 = new javax.swing.JTextField();//sale_emp_name
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton9 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();//month
        jLabel15 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();//log_empid
        jLabel9 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();//name
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton6 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jLabel10 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();//empid
        jLabel11 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();//password
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Al-Nayesh Mart:Manager");
        setVisible(true);
        setBounds(500, 200, 462, 307);
        
        Toolkit kit =Toolkit.getDefaultToolkit();
        Image image;
        image=kit.getDefaultToolkit().getImage("D:\\Documents\\NetBeansProjects\\AL_Nayesh\\src\\al_nayesh\\1_副本.png");
        setIconImage(image);
        
        addWindowListener(new java.awt.event.WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e) {
                try{
                Connect con =new Connect();
                con.stmt.execute("update logininformation set logout=getdate() where logid='"+logid+"'");
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, "Logout Time Does't Log.","Warning Message",JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        jTabbedPane1.setName("Inventory Management"); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},
                {null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},
                {null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},
                {null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},
                {null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null},{null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Gender", "Position", "PhoneNum"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel1.setText("Employee Information");

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setText("ID:");


        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("Name:");

        jLabel4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel4.setText("Gender:");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setText("Phone Number:");

        jLabel6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel6.setText("Position:");
//-----------------------------------------------------////--------------------------//---------
        jButton1.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton1.setText("Search");

        jButton2.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton2.setText("Add");

        jButton3.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton3.setText("Update");

        jButton4.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton4.setText("Delete");
//-----------------------------------------------------////--------------------------//---------
        jButton1.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent arg0) {
                        try {
		            	Connect con =new Connect();
		            	if(!jTextField1.getText().trim().isEmpty()){
		            	ResultSet rs=con.stmt.executeQuery("select * from Employee where empid='"+jTextField1.getText()+"'");
		            	rs.next();
		            	jTable1.setValueAt(rs.getString("empid"), 0, 0);
		            	jTable1.setValueAt(rs.getString("name"), 0, 1);
		            	jTable1.setValueAt(rs.getString("gender"), 0, 2);
		            	jTable1.setValueAt(rs.getString("pos"), 0, 3);
		            	jTable1.setValueAt(rs.getString("phone"), 0, 4);}
		            	else if(!jTextField2.getText().trim().isEmpty()){
		            	ResultSet rs=con.stmt.executeQuery("select * from Employee where name='"+jTextField2.getText()+"'");
		            	rs.next();
		            	jTable1.setValueAt(rs.getString("empid"), 0, 0);
		            	jTable1.setValueAt(rs.getString("name"), 0, 1);
		            	jTable1.setValueAt(rs.getString("gender"), 0, 2);
		            	jTable1.setValueAt(rs.getString("pos"), 0, 3);
		            	jTable1.setValueAt(rs.getString("phone"), 0, 4);}
		            else if(!jTextField3.getText().trim().isEmpty()){
		            	ResultSet rs=con.stmt.executeQuery("select * from Employee where gender='"+jTextField3.getText()+"'");
		            	int i=0;
		            	while(i<25){
			            	jTable1.setValueAt("", i, 0);
			            	jTable1.setValueAt("", i, 1);
			            	jTable1.setValueAt("", i, 2);
			            	jTable1.setValueAt("", i, 3);
			            	jTable1.setValueAt("", i, 4);
			            	i=i+1;}i=0;
		            	while(rs.next()){
		            	jTable1.setValueAt(rs.getString("empid"), i, 0);
		            	jTable1.setValueAt(rs.getString("name"), i, 1);
		            	jTable1.setValueAt(rs.getString("gender"), i, 2);
		            	jTable1.setValueAt(rs.getString("pos"), i, 3);
		            	jTable1.setValueAt(rs.getString("phone"), i, 4);
		            	i=i+1;}i=0;}
		            else if(!jTextField4.getText().trim().isEmpty()){
		            	ResultSet rs=con.stmt.executeQuery("select * from Employee where pos='"+jTextField4.getText()+"'");
		            	int i=0;
		            	while(i<25){
			            	jTable1.setValueAt("", i, 0);
			            	jTable1.setValueAt("", i, 1);
			            	jTable1.setValueAt("", i, 2);
			            	jTable1.setValueAt("", i, 3);
			            	jTable1.setValueAt("", i, 4);
			            	i=i+1;}i=0;
		            	while(rs.next()){
		            	jTable1.setValueAt(rs.getString("empid"), i, 0);
		            	jTable1.setValueAt(rs.getString("name"), i, 1);
		            	jTable1.setValueAt(rs.getString("gender"), i, 2);
		            	jTable1.setValueAt(rs.getString("pos"), i, 3);
		            	jTable1.setValueAt(rs.getString("phone"), i, 4);
		            	i=i+1;}i=0;
		            }
		            	else if(!jTextField5.getText().trim().isEmpty()){
			            	ResultSet rs=con.stmt.executeQuery("select * from Employee where phone='"+jTextField5.getText()+"'");
			            	rs.next();
			            	jTable1.setValueAt(rs.getString("empid"), 0, 0);
			            	jTable1.setValueAt(rs.getString("name"), 0, 1);
			            	jTable1.setValueAt(rs.getString("gender"), 0, 2);
			            	jTable1.setValueAt(rs.getString("pos"), 0, 3);
			            	jTable1.setValueAt(rs.getString("phone"), 0, 4);}
		            	else{JOptionPane.showMessageDialog(null, "PLEASE INSERT ID!!", "information", JOptionPane.INFORMATION_MESSAGE);}
                        }catch(Exception e){System.out.println(e+"加载驱动失败");}
			}
		});
        jButton2.addActionListener(new ActionListener() {
		@Override
			public void actionPerformed(ActionEvent arg0) {
				try {Connect con=new Connect();
					PreparedStatement stat;
					stat=con.set("insert into Employee values(?,?,?,?,?,?)");
					stat.setString(1,jTextField1.getText().trim());
					stat.setString(2,null);
					stat.setString(3,jTextField2.getText().trim());
					stat.setString(4,jTextField3.getText().trim());
					stat.setString(5,jTextField5.getText().trim());
					stat.setString(6,jTextField4.getText().trim());
					stat.executeUpdate();
					jTextField1.setText("");
					jTextField2.setText("");
					jTextField3.setText("");
					jTextField4.setText("");
					jTextField5.setText("");
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "SOMETHING WRONG!!", "information", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
        jButton3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try{Connect con=new Connect();
				PreparedStatement stat1,stat2;
				if(jTextField5.getText().trim().equals("")){stat1=con.set("update Employee set pos=? where empid= ?");
                                stat1.setString(2, jTextField1.getText().trim());
                                stat1.setString(1, jTextField4.getText().trim());
                                stat1.executeUpdate();}
				else{
                                stat2=con.set("update Employee set phone=? where empid= ?");
                                stat2.setString(2, jTextField1.getText().trim());
                                stat2.setString(1, jTextField5.getText().trim());
                                stat2.executeUpdate();}
				}catch(Exception e){System.out.println(e);}
			}
		});
        jButton4.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					Connect con=new Connect();
					PreparedStatement stat;
					stat=con.set("delete from Employee where empid= ?");
					stat.setString(1, jTextField1.getText().trim());
					stat.executeUpdate();
					}catch(Exception e){
						System.out.println(e);
					}
			}
		});
       jButton12.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			try {Connect con=new Connect();
				ResultSet rs1=con.stmt.executeQuery("select * from Inventory where invid='"+jTextField11.getText()+"'");
				if(rs1.next()){
				jTextField11.setText(rs1.getString("invid"));
				jTextField12.setText(rs1.getString("Goodsname"));
				jTextField13.setText(rs1.getString("price"));
				jTextField14.setText(rs1.getString("num"));
				jTextArea1.setText(rs1.getString("information"));}else {JOptionPane.showMessageDialog(null, "PLEASE INSERT THE RIGHT ID!!", "information", JOptionPane.INFORMATION_MESSAGE);}
			}catch(Exception e){
					System.out.println(e);
				}
		}
	});
       jButton11.addActionListener(new ActionListener() {
		@Override       
		public void actionPerformed(ActionEvent arg0) {
			try {
				Connect con=new Connect();
				PreparedStatement stat;
				stat=con.set("insert into Inventory values(?,?,?,?)");
			    stat.setString(1,jTextField12.getText());
                stat.setInt(2, Integer.parseInt(jTextField13.getText()));
                stat.setInt(3, Integer.parseInt(jTextField14.getText()));
                stat.setString(4, jTextArea1.getText());
                stat.executeUpdate();
                jTextField12.setText("");
                jTextField13.setText("");
                jTextField14.setText("");
                jTextArea1.setText("");
			}catch(Exception e){System.out.println(e);}
			
		}
	});

       jButton10.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			try {
                            if(!jTextField13.getText().isEmpty()){
				Connect con=new Connect();
				PreparedStatement stat;
				stat=con.set("update Inventory set price=? where invid=?");
				stat.setString(2, jTextField11.getText().trim());
				stat.setString(1, jTextField13.getText().trim());
				stat.executeUpdate();
                            }else{///////////////////
                                Connect con=new Connect();
				ResultSet rs=con.stmt.executeQuery( "select quantity from Inventory where invid='"+jTextField11.getText().toString().trim()+"'");
                                rs.next();
                                int oldquan =Integer.parseInt(rs.getString(1));
                                int newquan =Integer.parseInt(jTextField14.getText().toString().trim());
                                con.stmt.execute("update Inventory set totalsell="+(oldquan-newquan)+" where invid='"+jTextField11.getText().toString().trim()+"'");
                            }
			}catch(Exception e){System.out.println(e);}
		}
	});
      jButton7.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			try {Connect con=new Connect();
			PreparedStatement stat;
			stat=con.set("update Employee set password=? where empid=?");
			stat.setString(2, jTextField8.getText().trim());
			stat.setString(1, jTextField9.getText().trim());
			stat.executeUpdate();
			}catch(Exception e){System.out.println(e);}
		}
	});
      jButton8.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			System.out.println("g");
			try{Connect con=new Connect();
			ResultSet rs1=con.stmt.executeQuery("select sum(quantity) from SalesData where empid='"+jTextField10.getText().trim()+"'");
			if(rs1.next()){
			jTable3.setValueAt(jTextField10.getText(), 0, 0);
			jTable3.setValueAt(rs1.getString(1), 0, 1);}
			else {JOptionPane.showMessageDialog(null, "NULL", "information", JOptionPane.INFORMATION_MESSAGE);}
			}catch(Exception e){System.out.println(e);}
		}
	});
      jButton9.addActionListener(new ActionListener() {		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			try{Connect con=new Connect();
			ResultSet rs1=con.stmt.executeQuery("select sum(quantity) from SalesData where datepart(mm,[date])='"+jComboBox1.getSelectedItem().toString()+"'");
        if(rs1.next()){
			jTable4.setValueAt(jComboBox1.getSelectedItem().toString(), 0, 0);
			jTable4.setValueAt(rs1.getString(1), 0, 1);}
        }catch(Exception e){System.out.println(e);}
		}
	});
      jButton5.addActionListener(new ActionListener() {
  		@Override
  		public void actionPerformed(ActionEvent arg0) {
            try {
            Connect con =new Connect();
        	if(!jTextField6.getText().trim().isEmpty()){int k=0;
        	ResultSet rs=con.stmt.executeQuery("select * from logininformation where empid='"+jTextField6.getText()+"'");
        	int i=0;
        	while(i<25){
            	jTable2.setValueAt("", i, 0);
            	jTable2.setValueAt("", i, 1);
            	jTable2.setValueAt("", i, 2);
            	jTable2.setValueAt("", i, 3);
            	i=i+1;}
               	Connect con1 =new Connect();
                ResultSet rs1=con1.stmt.executeQuery("select name from employee where empid='"+jTextField6.getText()+"'");
                rs1.next();
            while(rs.next()){
        	jTable2.setValueAt(rs.getString("empid"), k, 0);
        	jTable2.setValueAt(rs1.getString(1), k, 1);  
        	jTable2.setValueAt(rs.getString("login"), k, 2);
        	jTable2.setValueAt(rs.getString("logout").toString(), k, 3);
        	k++;}k=0;}
        	else if(!jTextField7.getText().trim().isEmpty()){int k=0;
        	ResultSet rs=con.stmt.executeQuery("select * from logininformation where empid="+"(select empid from Employee where name="+"'"+jTextField7.getText()+"'"+")");
           	int i=0;
        	while(i<25){
            	jTable2.setValueAt("", i, 0);
            	jTable2.setValueAt("", i, 1);
            	jTable2.setValueAt("", i, 2);
            	jTable2.setValueAt("", i, 3);
            	i=i+1;}i=0;
               	Connect con1 =new Connect();
                ResultSet rs1=con1.stmt.executeQuery("select name from employee where name='"+jTextField7.getText()+"'");
                rs1.next();
        	while(rs.next()){
        	jTable2.setValueAt(rs.getString("empid"), k, 0);
        	jTable2.setValueAt(rs1.getString("name"), k, 1);
        	jTable2.setValueAt(rs.getString("login"), k, 2);
        	jTable2.setValueAt(rs.getString("logout"), k, 3);k++;}k=0;}
        	else {JOptionPane.showMessageDialog(null, "PLEASE VALUES!!", "information", JOptionPane.INFORMATION_MESSAGE);}
            }catch(Exception e){System.out.println(e);}
  		}
  	});
      jButton6.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(jRadioButton1.isSelected()){
               try{	Connect con =new Connect();
                ResultSet rs1=con.stmt.executeQuery("select empid,[login],logout from logininformation order by datepart(dd,[login])");
               	int i=0;
            	while(i<25){
                	jTable2.setValueAt("", i, 0);
                	jTable2.setValueAt("", i, 1);
                	jTable2.setValueAt("", i, 2);
                	jTable2.setValueAt("", i, 3);
                	i=i+1;}i=0;int k=0;
                   while(rs1.next()){                		
                    	jTable2.setValueAt(rs1.getString("empid"), k, 0);
                    	jTable2.setValueAt(rs1.getString("login"), k, 2);
                    	jTable2.setValueAt(rs1.getString("logout"), k, 3);
                    	Connect con1 =new Connect();
                        ResultSet rs2=con1.stmt.executeQuery("select name from Employee where empid= '"+jTable2.getValueAt(k, 0)+"'");
                        rs2.next();
                        jTable2.setValueAt(rs2.getString(1), k, 1);  
                        k++;}k=0;
			}catch (Exception e) {System.out.println(e);}}
			if(jRadioButton2.isSelected()){
	               try{	Connect con =new Connect();
	                ResultSet rs1=con.stmt.executeQuery("select empid,[login],logout from logininformation order by datepart(ww,[login])");
	               	int i=0;
	            	while(i<25){
	                	jTable2.setValueAt("", i, 0);
	                	jTable2.setValueAt("", i, 1);
	                	jTable2.setValueAt("", i, 2);
	                	jTable2.setValueAt("", i, 3);
	                	i=i+1;}i=0;int k=0;
	                   while(rs1.next()){                		
	                    	jTable2.setValueAt(rs1.getString("empid"), k, 0);
	                    	jTable2.setValueAt(rs1.getString("login"), k, 2);
	                    	jTable2.setValueAt(rs1.getString("logout"), k, 3);
	                    	Connect con1 =new Connect();
	                        ResultSet rs2=con1.stmt.executeQuery("select name from Employee where empid= '"+jTable2.getValueAt(k, 0)+"'");
	                        rs2.next();
	                        jTable2.setValueAt(rs2.getString(1), k, 1);  
	                        k++;}k=0;
				}catch (Exception e) {System.out.println(e);}}
			if(jRadioButton3.isSelected()){
	               try{	Connect con =new Connect();
	                ResultSet rs1=con.stmt.executeQuery("select empid,[login],logout from logininformation order by datepart(mm,[login])");
	               	int i=0;
	            	while(i<25){
	                	jTable2.setValueAt("", i, 0);
	                	jTable2.setValueAt("", i, 1);
	                	jTable2.setValueAt("", i, 2);
	                	jTable2.setValueAt("", i, 3);
	                	i=i+1;}i=0;int k=0;
	                   while(rs1.next()){                		
	                    	jTable2.setValueAt(rs1.getString("empid"), k, 0);
	                    	jTable2.setValueAt(rs1.getString("login"), k, 2);
	                    	jTable2.setValueAt(rs1.getString("logout"), k, 3);
	                    	Connect con1 =new Connect();
	                        ResultSet rs2=con1.stmt.executeQuery("select name from Employee where empid= '"+jTable2.getValueAt(k, 0)+"'");
	                        rs2.next();
	                        jTable2.setValueAt(rs2.getString(1), k, 1);  
	                        k++;}k=0;
				}catch (Exception e) {System.out.println(e);}}
			if(jRadioButton4.isSelected()){
	               try{	Connect con =new Connect();
	                ResultSet rs1=con.stmt.executeQuery("select empid,[login],logout from logininformation order by datepart(yy,[login])");
	               	int i=0;
	            	while(i<25){
	                	jTable2.setValueAt("", i, 0);
	                	jTable2.setValueAt("", i, 1);
	                	jTable2.setValueAt("", i, 2);
	                	jTable2.setValueAt("", i, 3);
	                	i=i+1;}i=0;int k=0;
	                   while(rs1.next()){                		
	                    	jTable2.setValueAt(rs1.getString("empid"), k, 0);
	                    	jTable2.setValueAt(rs1.getString("login"), k, 2);
	                    	jTable2.setValueAt(rs1.getString("logout"), k, 3);
	                    	Connect con1 =new Connect();
	                        ResultSet rs2=con1.stmt.executeQuery("select name from Employee where empid= '"+jTable2.getValueAt(k, 0)+"'");
	                        rs2.next();
	                        jTable2.setValueAt(rs2.getString(1), k, 1);  
	                        k++;}k=0;
				}catch (Exception e) {System.out.println(e);}}
    		}
	});	
      //jRadioButton//----------------------------------------
      jRadioButton1.addActionListener(new ActionListener() {
    	@Override
		public void actionPerformed(ActionEvent arg0) {
    		if(jRadioButton1.isSelected()){
			jRadioButton2.setVisible(false);
			jRadioButton3.setVisible(false);
			jRadioButton4.setVisible(false);
		}else{jRadioButton2.setVisible(true);
			jRadioButton3.setVisible(true);
			jRadioButton4.setVisible(true);}
    	}
	});
      jRadioButton2.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
	 		if(jRadioButton2.isSelected()){
				jRadioButton1.setVisible(false);
				jRadioButton3.setVisible(false);
				jRadioButton4.setVisible(false);
			}else{jRadioButton1.setVisible(true);
				jRadioButton3.setVisible(true);
				jRadioButton4.setVisible(true);}
	    	}	
	});
      jRadioButton3.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(jRadioButton3.isSelected()){
				jRadioButton1.setVisible(false);
				jRadioButton2.setVisible(false);
				jRadioButton4.setVisible(false);
			}else{jRadioButton1.setVisible(true);
				jRadioButton2.setVisible(true);
				jRadioButton4.setVisible(true);}	    	
		}
	});
      jRadioButton4.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(jRadioButton4.isSelected()){
				jRadioButton1.setVisible(false);
				jRadioButton2.setVisible(false);
				jRadioButton3.setVisible(false);
			}else{jRadioButton1.setVisible(true);
				jRadioButton2.setVisible(true);
				jRadioButton3.setVisible(true);}
	    	}
	});

      javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton1))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField5))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton3)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton4)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addComponent(jLabel1))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Employee Management", jPanel1);

        jLabel12.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel12.setText("Inventory Information:");

        jLabel16.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel16.setText("Pro_ID:");

        jLabel17.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel17.setText("Name:");


        jLabel18.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel18.setText("Price:");

        jLabel19.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel19.setText("Quantity:");

        jLabel20.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel20.setText("Pro_Information:");

        jButton10.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton10.setText("Update");

        jButton11.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton11.setText("Add");

        jButton12.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton12.setText("Search");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane6.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel12)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField13))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton10)
                        .addContainerGap(85, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton11))
                            .addComponent(jScrollPane6))
                        .addGap(10, 10, 10))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton11)
                    .addComponent(jButton12))
                .addGap(78, 78, 78))
        );

        jTabbedPane1.addTab("Inventory Management", jPanel2);

        jLabel13.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel13.setText("Sales Information:");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "Employee", "Total"
            }
        ) {Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jButton8.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton8.setText("Search");

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "Month", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jButton9.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton9.setText("Search");

        jLabel14.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel14.setText("Employee ID:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        jLabel15.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel15.setText("Month:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 46, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(jButton9))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton8))))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton9)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Sales Data", jPanel3);

        jLabel7.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel7.setText("Log Information:");

        jLabel8.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel8.setText("ID:");

        jLabel9.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel9.setText("Name:");

        jButton5.setText("Search");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},
                {null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},
                {null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null},{null, null, null, null}
            },
            new String [] {
                "ID", "Name", "LogIn", "LogOut"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jButton6.setText("Search All");

        jRadioButton1.setText("Day");

        jRadioButton2.setText("Week");

        jRadioButton3.setText("Month");

        jRadioButton4.setText("Year");
        
        jLabel10.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel10.setText("ID:");



        jLabel11.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel11.setText("New Password:");

        jButton7.setText("Submit");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jRadioButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton3)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton6))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 417, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3)
                    .addComponent(jRadioButton4)
                    )
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("User Log", jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("Inventory Management");

        pack();
    }
    public void getlog(String id){
        logid=id;
    }
    // </editor-fold>                      
    
    // Variables declaration - do not modify   
    String logid;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration          
   
}