/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author student
 */
public class ShowProducts extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
                String name ,pwd ;
                name=request.getParameter("uname");
                pwd=request.getParameter("pass");
                HttpSession session=request.getSession();
                session.setAttribute("name", name);
                if(name.equals("Thomas") & pwd.equals("123456")){
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Show Products</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("Welcome "+ name);
                out.println("</br>");
                out.println("<form action=\"ShowRecords\">");
                out.println("<table border=1 align=center>");
                out.println("<tr><th>Serial No:</th><th>Product Name:</th><th>Price</th><th>Choice:</th></tr>");
                out.println("<tr><td>1</td><td>Micromax Bolt Q335</td><td>$340</td><td><input type=checkbox name=c1 /></td></tr>");
                out.println("<tr><td>2</td><td>iBall Class X</td><td>$432</td><td><input type=checkbox name=c2 /></td></tr>");
                out.println("<tr><td>3</td><td>HTC 820G</td><td>$346</td><td><input type=checkbox name=c3 /></td></tr>");
                out.println("<tr><td>4</td><td>Panasonic Eluga Z</td><td>$445</td><td><input type=checkbox name=c4 /></td></tr>");
                out.println("<tr><td>5</td><td>Micromax Canvas Selfie</td><td>$456</td><td><input type=checkbox name=c5 /></td></tr>");
                out.println("</table>");
                out.println("<input align=center type=submit>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
                }else{
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Show Products</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<p>Your password is incorrect.</p>");
                out.println("<a href=\"LoginForm.html\">Go back to login.</a>");
                out.println("</body>");
                out.println("</html>");
                }
                
             }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
