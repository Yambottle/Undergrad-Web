/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import java.util.ArrayList;


/**
 *
 * @author user
 */
public class EmailBean {
    private Email e ;
    private String name ,age ,dob ,pwd  ;
    /**
     * Creates a new instance of EmailBean
     */
    public EmailBean() {
    }

    public Email getE() {
        return e;
    }

    public void setE(Email e) {
        this.e = e;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public String greet(){
        return "success";
    }
    
    public String printMsg(String name,String age, String dob, String pwd ){
        ArrayList<String> email = new ArrayList();
        email.add(name);
        email.add(age);
        email.add(dob);
        email.add(pwd);
        return e.success(email);
    }
}
