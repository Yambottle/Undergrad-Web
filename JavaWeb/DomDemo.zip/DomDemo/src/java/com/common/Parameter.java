/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.common;

import java.io.Serializable;

/**
 *
 * @author Administrator
 */
public class Parameter implements Serializable{
    public final static String SUCCESS_CODE = "00000";
    public final static String FALSE_CODE = "10000";
    //public final static String url ="";
}
