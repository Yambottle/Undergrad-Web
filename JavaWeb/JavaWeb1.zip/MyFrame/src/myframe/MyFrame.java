package myframe;
import java.awt.Color;

import java.awt.Graphics;

import java.awt.Graphics2D;

 

import javax.swing.JFrame;

import javax.swing.JPanel;

 

public class MyFrame extends JFrame {

 

         /**

          *

          */

         private static final long serialVersionUID = 1L;

 

         class MyPanel extends JPanel {

 

                   /**

                    *

                    */

                   private static final long serialVersionUID = 1L;

 

                   public void paint(Graphics graphics) {

                            super.paint(graphics);

                            Graphics g2d = (Graphics2D) graphics;

                            g2d.setColor(Color.black);

                            g2d.draw3DRect(0, 0, 400, 500, true);
                            g2d.drawLine(10, 10, 10, 10);

                   }

         }

 

         public MyFrame() {

                   this.add(new MyPanel());

                   this.setSize(800, 600);

         }

 

         public static void main(String[] args) {

                   MyFrame frame = new MyFrame();

                   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                   frame.setVisible(true);

         }

}

 

