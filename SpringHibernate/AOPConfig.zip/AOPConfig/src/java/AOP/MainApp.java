/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AOP;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author NIIT
 */
public class MainApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ApplicationContext ac = new ClassPathXmlApplicationContext("AOP/Spring-Config.xml");
        Student s = (Student) ac.getBean("student");
        s.getName();
        s.getAge();
        s.throwException();
    }
    
}
