
package weishu;

public class Weishu {

    public static void main(String[] args) {
        String arch =System.getProperty("sun.arch.data.model");
        System.out.println(arch+"-bit");
    }
    
}
