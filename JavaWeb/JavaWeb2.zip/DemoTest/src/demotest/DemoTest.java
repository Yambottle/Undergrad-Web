/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demotest;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Thomas
 */
public class DemoTest {

    private Map<Integer, Integer> numMap;
    private List<Integer> numList;
    
    public static void main(String[] args){
        boolean flag = true;
        DemoTest dt = new DemoTest();
        while(flag){
            System.out.println("请输入所需操作：1.展示图形 in For 2.遍历结构 3.封装结构 4.封装解析 5.展示图形 in While 0.退出");
            Scanner in = new Scanner(System.in);
            switch(in.nextInt()){
                case 1:
                    dt.showShapeInFor();
                    break;
                case 2:
                    dt.listMap();
                    break;
                case 3:
                    dt.showJson();
                    break;
                case 4:
                    dt.toFromJson();
                    break;
                case 5:
                    dt.showShapeInWhile();
                    break;
                case 0:
                    flag = false;
                    break;
                default:
                    flag = false;
                    break;
            }
        }
    }
    
    public void showShapeInFor(){
        System.out.println("请输入行数：");
        Scanner ini = new Scanner(System.in);
        int i = ini.nextInt();
        System.out.println("请输入列数：");
        Scanner inj = new Scanner(System.in);
        int j = ini.nextInt();
        
        System.out.println("实心三角形：");
        for(int m=0;m<i;m++){
            for(int b=0;b<(i-m+1);b++){
                    System.out.print(" ");
            }
            for(int n=0;n<=m;n++){
                System.out.print("* ");
            }
            System.out.println("");
        }
        
        System.out.println("空心三角形：");
        for(int m=0;m<i;m++){
            for(int b=0;b<(i-m+1);b++){
                    System.out.print(" ");
            }
            for(int n=0;n<=m;n++){
                if(n==0||n==m){
                    System.out.print("* ");
                }else{
                    if(m!=(i-1)){
                        System.out.print("  ");
                    }else{
                        System.out.print("* ");
                    }
                }
            }
            System.out.println("");
        }
        
        System.out.println("实心菱形：");
        for(int m=0;m<i;m++){
            for(int b=0;b<(i-m);b++){
                    System.out.print(" ");
            }
            for(int n=0;n<=m;n++){
                System.out.print("* ");
            }
            System.out.println("");
        }
        for(int m=i-1;m>0;m--){
            for(int b=0;b<(i-m+1);b++){
                System.out.print(" ");
            }
            for(int n=0;n<=m-1;n++){
                System.out.print("* ");
            }
            System.out.println("");
        }
        
        System.out.println("空心菱形：");
        for(int m=0;m<i;m++){
            for(int b=0;b<(i-m);b++){
                    System.out.print(" ");
            }
            for(int n=0;n<=m;n++){
                if(n==0||n==m){
                    System.out.print("* ");
                }else{
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
        for(int m=i-1;m>0;m--){
            for(int b=0;b<(i-m+1);b++){
                System.out.print(" ");
            }
            for(int n=0;n<=m-1;n++){
                if(n==0||n==m-1){
                    System.out.print("* ");
                }else{
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
    }
    
    public void showShapeInWhile(){
        System.out.println("请输入行数：");
        Scanner ini = new Scanner(System.in);
        int i = ini.nextInt();
        System.out.println("请输入列数：");
        Scanner inj = new Scanner(System.in);
        int j = ini.nextInt();
        
        System.out.println("实心三角形：");
        int m = 0;
        while(m<i){
            int b = 0;
            while(b<(i-m+1)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m){
                System.out.print("* ");
                n++;
            }
            System.out.println("");
            m++;
        }
        
        System.out.println("空心三角形：");      
        m=0;
        while(m<i){
            int b = 0;
            while(b<(i-m+1)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m){
                if(n==0||n==m){
                    System.out.print("* ");
                }else{
                    if(m!=(i-1)){
                        System.out.print("  ");
                    }else{
                        System.out.print("* ");
                    }
                }
                n++;
            }
            System.out.println("");
            m++;
        }
        
        System.out.println("实心菱形：");
        m = 0;
        while(m<i){
            int b = 0;
            while(b<(i-m)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m){
                System.out.print("* ");
                n++;
            }
            System.out.println("");
            m++;
        }
        m = i-1;
        while(m>0){
            int b = 0;
            while(b<(i-m+1)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m-1){
                System.out.print("* ");
                n++;
            }
            System.out.println("");
            m--;
        }
        
        
        System.out.println("空心菱形：");
        m = 0;
        while(m<i){
            int b = 0;
            while(b<(i-m)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m){
                if(n==0||n==m){
                    System.out.print("* ");
                }else{
                    System.out.print("  ");
                }
                n++;
            }
            System.out.println("");
            m++;
        }
        m = i-1;
        while(m>0){
            int b = 0;
            while(b<(i-m+1)){
                System.out.print(" ");
                b++;
            }
            int n = 0;
            while(n<=m-1){
                if(n==0||n==m-1){
                    System.out.print("* ");
                }else{
                    System.out.print("  ");
                }
                n++;
            }
            System.out.println("");
            m--;
        }
    }
    
    public void listMap(){
        //init
        int[] array = new int[10];
        List<Integer> list = new ArrayList();
        Map<Integer, Integer> map = new HashMap();
        for(int i = 1 ; i <= 10 ; i++){
            array[i-1] = i;
            list.add(i);
            map.put(i, i);
        }
        numMap = map;
        numList = list;
        //print
        System.out.println("Array:");
        for(int i = 1 ; i <= 10 ; i++){
            System.out.print(array[i-1]+" ");
        }
        System.out.println("");
        
        System.out.println("List:(Iterator)");
        Iterator it = list.iterator();
        while(it.hasNext()){
            System.out.print(it.next()+" ");
        }
        System.out.println("");
        
        System.out.println("List:(for-each)");
        for(Integer i : list){
            System.out.print(i+" ");
        }
        System.out.println("");
        
        System.out.println("Map:");
        for(Map.Entry entry : map.entrySet()){
            System.out.print("Key:"+entry.getKey()+" Value:"+entry.getValue()+"||");
        }
        System.out.println("");
        System.out.println("");
        
    }
    
    public void showJson(){
        Gson gson = new Gson();
        if(numMap == null || numList == null){
            numMap = new HashMap<>();
            numList = new ArrayList<>();
        }
        if(numMap.isEmpty() || numList.isEmpty()){
            for(int i = 1 ; i <= 10 ; i++){
            numList.add(i);
            numMap.put(i, i);
        }
        }
        System.out.println("Map-Json:"+gson.toJson(numMap));
        System.out.println("List-Json:"+gson.toJson(numList));
        
        System.out.println("");
    }
    
    public void toFromJson(){
        Gson gson = new Gson();
        Map<String, Entity> map = new HashMap<>();
        List<Entity> list = new ArrayList<>();
        for(Integer i = 0 ; i < 10 ; i++ ){
            Entity en = new Entity();
            en.setId(i.toString());
            en.setName(i.toString());
            map.put(i.toString(), en);
            list.add(en);
        }
        String mapJson = gson.toJson(map);
        String listJson = gson.toJson(list);
        
        Map<String, Entity> mapFromJson = gson.fromJson(mapJson, new TypeToken<HashMap<String, Entity>>(){}.getType());
        List<Entity> listFromJson = gson.fromJson(listJson, new TypeToken<ArrayList<Entity>>(){}.getType());
        
        System.out.println("mapFromJson key=0 Entity's id:"+mapFromJson.get("0").getId());
        System.out.println("listFromJson first Entity's id:"+listFromJson.get(0).getId());
    }
}