/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imgdm;

import algorithm.C4_5;
import algorithm.Two;
import java.util.ArrayList;
import java.util.List;
import util.CSVFileRWUtil;

/**
 *
 * @author Lenovo
 */
public class IMGDM {

    /**
     * 获取列表中每一行的最大值
     *
     * @param list
     * @param index
     * @return
     */
    public static int Max(List list, int index) {
        int max = 0;
        List line = (List) list.get(0);
        max = Integer.parseInt(line.get(index).toString());
        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
//            println(Integer.parseInt(line.get(index).toString()));
            if (Integer.parseInt(line.get(index).toString()) > max) {
//                println(line.get(index).toString());
                max = Integer.parseInt(line.get(index).toString());
            }
        }
        return max;
    }

    /**
     * 获取列表中每一行的最小值
     *
     * @param list
     * @param index
     * @return
     */
    public static int Min(List list, int index) {
        int min = 0;
        List line = (List) list.get(0);
        min = Integer.parseInt(line.get(index).toString());
        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (Integer.parseInt(line.get(index).toString()) < min) {
                min = Integer.parseInt(line.get(index).toString());
            }
        }
        return min;
    }

    public static int getX(List list, int index, String type) {
        int x = 0;
        List line;
        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (line.get(5).toString().equals(type)) {
                x++;
            }
        }
        return x;
    }

    public static int getY(List list, int index, String type) {
        int y = 0;
        List line;
        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (!line.get(5).toString().equals(type)) {
                y++;
            }
        }
        return y;
    }

    public static void println(Object obj) {
        System.out.println(obj);
    }

    public static List getExDataList(List list, int index, int split, String type) {
        List dataList = new ArrayList();
        List line;

        Two a = new Two(0, 0);
        Two b = new Two(0, 0);

        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (Integer.parseInt(line.get(index).toString()) <= split) {
                if (line.get(5).toString().equals(type)) {
                    a.setA(a.getA() + 1);
                } else {
                    a.setB(a.getB() + 1);
                }
            } else if (line.get(5).toString().equals(type)) {

                b.setA(b.getA() + 1);
            } else {
                b.setB(b.getB() + 1);
            }
        }
        dataList.add(a);
        dataList.add(b);
        return dataList;
    }

    public static int getM(List list, int index, int split) {
        int m = 0;
        List line;

        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (Integer.parseInt(line.get(index).toString()) <= split) {
                m++;
            }
        }
        return m;
    }

    public static int getN(List list, int index, int split) {
        int n = 0;
        List line;

        for (Object object : list) {
            line = (List) object;
            if (line.size() < index) {
                continue;
            }
            if (Integer.parseInt(line.get(index).toString()) > split) {
                n++;
            }
        }
        return n;
    }

    /**
     * 根据C4.5算法处理样本
     * @param boDuan //列数 实际波段+1
     * @param type //要计算的类型1， 2， 3
     * @throws Exception 
     */
    public void handleSample(int boDuan, String type) throws Exception {
        List sampleList = new ArrayList();

        CSVFileRWUtil sVFileRWUtil = new CSVFileRWUtil("C:\\Users\\Administrator\\Desktop\\基于决策树c45的HJ影像海岸带地物分类规则挖掘\\sample.txt");
        List line = CSVFileRWUtil.fromCSVLinetoArray(sVFileRWUtil.readLine());
        while (!line.isEmpty()) {
            line = CSVFileRWUtil.fromCSVLinetoArray(sVFileRWUtil.readLine());
            sampleList.add(line);
        }

        int max = Max(sampleList, boDuan); //分界值上界
        int min = Min(sampleList, boDuan); //分界值下界
//        println("max: " + max + "  min: " + min);
        double maxGR = 0.0; //最大增益率
        int split = 0; //最大期望时的分界值

        //计算增益率所需参数
        int x = getX(sampleList, boDuan, type); // 分割结果集，用于计算gain
        int y = getY(sampleList, boDuan, type); // 分割结果集，用于计算gain

//        System.out.println("x: "+x+"  y: "+y);
//        System.out.println("samplelist size: "+sampleList.size());
        for (int i = min; i <= max; i++) {
            //计算增益率所需参数
            List data = getExDataList(sampleList, boDuan, i, type); // 分割结果集，用于计算gain
            int m = getM(sampleList, boDuan, i); // 分割属性集，计算Split_info
            int n = getN(sampleList, boDuan, i); // 分割属性集，计算Split_info
//            System.out.println("================= ");
//            System.out.println("i: " + i);
//            System.out.println("x: " + x);
//            System.out.println("y: " + y);
            Two two1 = (Two) data.get(0);
            Two two2 = (Two) data.get(1);
//            System.out.println("data: " + two1.toString() + two2.toString());
//            System.out.println("m: " + m);
//            System.out.println("n: " + n);

            //计算增益率
            double GR = C4_5.Gain_ratio(x, y, data, m, n);
            //计算最大增益率
            if (GR > maxGR) {
                maxGR = GR;
                split = i;
            }
        }
        System.out.println("================= ");
        System.out.println("根据波段： "+boDuan+" 类型： "+type+" 分析结果：");
        System.out.println("最优分类值： "+split);
        System.out.println("最大增益率： "+maxGR);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        IMGDM imgdm = new IMGDM();
        imgdm.handleSample(2, "1");
        imgdm.handleSample(3, "1");
        imgdm.handleSample(4, "1");
        
        imgdm.handleSample(2, "2");
        imgdm.handleSample(3, "2");
        imgdm.handleSample(4, "2");
        
        imgdm.handleSample(2, "3");
        imgdm.handleSample(3, "3");
        imgdm.handleSample(4, "3");
    }

}
