/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            PrintWriter out = response.getWriter();
            String role = request.getParameter("rd");
            String id = request.getParameter("id");
            String pwd = request.getParameter("pwd");
            if(role == null ||role.equals("")||id==null||id.equals("")||pwd==null||pwd.equals("")){
                role=(String)request.getAttribute("role");
                id=(String)request.getAttribute("id");
                pwd=(String)request.getAttribute("pwd");
            }
            
            Connect con = new Connect();
            ResultSet rs=null;
            
            if(role.equals("S")){
                rs=con.stmt.executeQuery("select pwd,ename,cname from student where regno ='" +id+"'");
                rs.next();
                if(rs.getString(1).equals(pwd)){
                    con.con.close();
                    //Student页面//MID
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet Regist</title>");            
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<form name=\"Student\" action=\"post\">");
                    out.println("<h1>Welcome "+rs.getString(2)+","+rs.getString(3)+"!</h1>");
                    out.println("Please choose the module.<br>");
                    //下拉菜单
                    rs=con.stmt.executeQuery("select * from modules");
                    out.println("<select id=\"selectOption\">");
                    while(rs.next())
                    out.println("<option value=\""+rs.getString(1)+"\" name=\"select\">"+rs.getString(2)+"</option>");
                    out.println("</select><br>");  
                    out.println("<input type=\"submit\" value=\"Choose\"/>");
                    out.println("</form>");
                    out.println("</body>");
                    out.println("</html>");
                }else{
                    out.println("Your password is incorrect or your ID is inexistent.<br>");
                    out.println("<a href=\"index.html\">Go Back...</a>");
                }
            }else{
                rs=con.stmt.executeQuery("select pwd from teacher where tid ='" +id+"'");
                rs.next();
                if(rs.getString(1).equals(pwd)){
                    con.con.close();
                    //Admin页面
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet Regist</title>");            
                    out.println("</head>");
                    out.println("<body>");
                    
                    out.println("<h2>View the student's performance.</h2>");
                    out.println("<form action=\"Admin\" method=\"post\">");
                    out.println("Enter the ID of the student:<input type=\"text\" name=\"id\"/><br>");
                    out.println("Enter the ID of the module:<input type=\"text\" name=\"mid\"/><br>");
                    out.println("<input type=\"submit\" value=\"VIEW\"/><br>");
                    out.println("</form>");
                    
                    out.println("<h2>Update the question.</h2>");
                    out.println("<form action=\"Update\" method=\"post\">");
                    out.println("Question ID:<input type=\"text\" name=\"qid\"/><br>");
                    out.println("Module ID:<input type=\"text\" name=\"mid\"/><br>");
                    out.println("Teacher ID:<input type=\"text\" name=\"tid\"/><br>");
                    out.println("Description:<input type=\"text\" name=\"descrip\"/><br>");
                    out.println("Choice A:<input type=\"text\" name=\"ca\"/><br>");
                    out.println("Choice B:<input type=\"text\" name=\"cb\"/><br>");
                    out.println("Choice C:<input type=\"text\" name=\"cc\"/><br>");
                    out.println("Choice D:<input type=\"text\" name=\"cd\"/><br>");
                    out.println("Answer:<input type=\"text\" name=\"ans\"/><br>");
                    out.println("Score:<input type=\"text\" name=\"qscore\"/><br>");
                    out.println("<input type=\"submit\" value=\"UPDATE\"/><br>");
                    out.println("</form>");
                    out.println("</body>");
                    out.println("</html>");
                }else{
                    out.println("Your password is incorrect or your ID is inexistent.<br>");
                    out.println("<a href=\"index.html\">Go Back...</a>");
                } 
            }
        } catch (SQLException ex) {
            ex.toString();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
