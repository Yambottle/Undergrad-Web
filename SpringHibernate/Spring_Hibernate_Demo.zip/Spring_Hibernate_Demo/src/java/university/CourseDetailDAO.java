/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author user
 */
public class CourseDetailDAO {
    
    private SessionFactory sessionFactory ;
    
    public CourseDetailDAO(){
        Configuration configration = new Configuration().configure();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public List getCourseByName(String courseName ){
        List<Course> courseList = null;
        try{
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            Criteria criteria = session.createCriteria(Course.class).add(Restrictions.eq("coursename", courseName));
            courseList = (List<Course>) criteria.list();
            transaction.commit();
            session.close();
        }catch(Exception e ){
            e.printStackTrace();
        }
        return courseList;
    }
}
