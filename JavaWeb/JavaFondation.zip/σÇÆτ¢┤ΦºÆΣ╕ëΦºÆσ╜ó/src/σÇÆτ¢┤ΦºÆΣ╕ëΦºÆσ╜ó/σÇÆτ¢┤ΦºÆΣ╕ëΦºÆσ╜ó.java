/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package 倒直角三角形;

/**
 *
 * @author Administrator
 */
public class 倒直角三角形 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i,j;
        for(i=1;i<=5;i++)
        {
          for(j=5;j>=i;j--)
          {System.out.print("*");
          }
            System.out.println("\n");
        
        }
    }
    
}
