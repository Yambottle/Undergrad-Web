/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package datamine;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Administrator
 */
public class MiningConnection {
    
    Connection connection;
    Map<String, Integer> oneLevFlagMap, totalByCourseMap,resultMap;
    List<String> oneLevList, threeLevList, threeLevFlagList, fourLevList,fourLevFlagList,resultList; 
    double minSupport = 0.15;
    String flagString = "";
    
    public MiningConnection(Connection connection){
        this.connection = connection;
        oneLevFlagMap = new HashMap<>();
        totalByCourseMap = new HashMap<>();
        oneLevList = new ArrayList<>();
        threeLevList = new ArrayList<>();
        threeLevFlagList = new ArrayList<>();
        fourLevList = new ArrayList<>();
        resultList = new ArrayList<>();
        resultMap = new HashMap<>();
    }
    
    public ResultSet search(String sql){
        
        Statement stat;
        ResultSet rs=null;
        try {
            stat =  connection.createStatement();
            rs = stat.executeQuery(sql);//"select * from DataMine.dbo.Sheet"
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rs;
    }
    
    public void oneLevelSet(){
        try{
            String oneLevSql = "select courseID,count(distinct stuID) from Sheet where grades >90 group by courseID";
            ResultSet oneLevRS ;
            oneLevRS = search(oneLevSql);// >90
            while(oneLevRS.next()){
                oneLevFlagMap.put(oneLevRS.getString(1),oneLevRS.getInt(2));
            }
            
            String totalByCourseSql = "select courseID,count(distinct stuID) from Sheet group by courseID";
            ResultSet totalByCourseRS ;
            totalByCourseRS = search(totalByCourseSql);// total by course
            while(totalByCourseRS.next()){
                totalByCourseMap.put(totalByCourseRS.getString(1),totalByCourseRS.getInt(2));
            }
            
            for(Map.Entry<String , Integer> flagEntry:oneLevFlagMap.entrySet()){
                for(Map.Entry<String , Integer> totalEntry:totalByCourseMap.entrySet()){
                    if(flagEntry.getKey().equals(totalEntry.getKey())){
                        if(flagEntry.getValue()*1.0/totalEntry.getValue() > minSupport){
                            oneLevList.add(flagEntry.getKey());
                        }
                    }
                }
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    } 
    
    public void process(){
        for(String course1 :oneLevList){
            for(String course2 :oneLevList){
                for(String course3 :oneLevList){
                        threeLevList.add(course1+","+course2+","+course3);
                }
            }
        }
        for(String three :threeLevList){
            String t[] = new String[3];
            t = three.split(",");
            if(t[0].equals(t[1])||t[0].equals(t[2])||t[1].equals(t[2])){
                continue;
            }
            threeLevFlagList.add(three);
        }
        for(String course4 :oneLevList){
            for(String three :threeLevFlagList){
                String t[] = new String[3];
                t = three.split(",");
                if(course4.equals(t[0])||course4.equals(t[1])||course4.equals(t[2])){
                }else{
                    try{
//                        String stuIDSql = "select distinct stuID from Sheet ";
//                        ResultSet stuIDRS;
//                        stuIDRS = search(stuIDSql);//stuID
//                        while(stuIDRS.next()){
                            String fourCoursePersonSql = "select count(distinct stuID) from Sheet where grades>90 and courseID in("+"'"+t[0]+"','"+t[1]+"','"+t[2]+"','"+course4+"')";// and stuID="+stuIDRS.getDouble(1);
                            ResultSet fourCoursePersonRS ;
                            fourCoursePersonRS = search(fourCoursePersonSql);
                            
                            String fourCourseTotalSql = "select count(distinct stuID) from Sheet where courseID in("+"'"+t[0]+"','"+t[1]+"','"+t[2]+"','"+course4+"')";// and stuID="+stuIDRS.getDouble(1);
                            ResultSet fourCourseTotalRS ;
                            fourCourseTotalRS = search(fourCourseTotalSql);
                            
                            if(fourCoursePersonRS != null && fourCourseTotalRS != null){
                                fourCoursePersonRS.next();fourCourseTotalRS.next();
                                if(fourCoursePersonRS.getInt(1)*1.0/fourCourseTotalRS.getInt(1)>minSupport){ 
                                    if(flagString.equals(t[0]+","+t[1]+","+t[2]+","+course4)){
                                        break;
                                    }else{
                                        flagString =t[0]+","+t[1]+","+t[2]+","+course4;
                                        System.out.println(t[0]+","+t[1]+","+t[2]+","+course4);
                                    }
                                        
                                }
                            }
                       //}
                    }catch(SQLException ex){
                        ex.printStackTrace();
                    }
                }
            }
        }
         
    }  
}
