
package al_nayesh;
import java.sql.*;

public class Connect {
    Statement stmt;
    Connection con;
    public Connect(){
        try{Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=ALNayesh;user=sa;password=niit");
            stmt=con.createStatement();
        }catch(Exception e){System.out.println(e.toString());}
    }
    public PreparedStatement set(String s){
    	try {
    		PreparedStatement stat=con.prepareStatement(s);
    		return stat;
		}catch (SQLException e) {e.printStackTrace();}
		return null;
    }  
}