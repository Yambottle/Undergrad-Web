package service;
public class LoginService {
public String sayHello(String name){
    return "Hello "+name+"!";
}
}
