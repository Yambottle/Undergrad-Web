
package 数组;
import java.util.Scanner;

public class 数组 {

    public static void main(String[] args) {
        int a[]={8,4,2,1,23,344,12};
        //循环输出
        int i;
        for(i=0;i<7;i++)
        {System.out.println(a[i]);
        }
        //数列求和
        int j,sum=0;
        for(j=0;j<7;j++)
        {sum=sum+a[j];
        }
        System.out.println(sum);
        //猜数游戏
        int k=0,l=0,m;
        System.out.println("请输入一个数：");
        Scanner input=new Scanner(System.in);
        m=input.nextInt();

        do{
            l=a[k]%10;
            if(a[k]==0)
             k++;
          }while(l==m);
       
        if(l==m)
            System.out.println("您猜错了。");
        else
            System.out.println("您猜对了。");
        
            
        
    }
    
}
