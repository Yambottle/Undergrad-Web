/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class IMGDMFileUtil {

    CSVFileRWUtil cSVFileRWUtil;
    private BufferedReader br;
    FileWriterUtil fileWriter;

    public IMGDMFileUtil(String filename) throws Exception {
        cSVFileRWUtil = new CSVFileRWUtil(filename);
        fileWriter = new FileWriterUtil();
        fileWriter.setFileRelativePath("src\\data");
    }

    /**
     *
     * @param fromX 开始列数
     * @param fromY 开始行数
     * @param toX 结束列数
     * @param toY 结束行数
     * @return
     * @throws Exception
     */
    public String readLine(int fromX, int fromY, int toX, int toY) throws Exception {
        List line = CSVFileRWUtil.fromCSVLinetoArray(cSVFileRWUtil.readLine());
        while (!line.isEmpty()) {
            if (Integer.parseInt(line.get(0).toString()) >= fromY && Integer.parseInt(line.get(0).toString()) <= toY
                    && Integer.parseInt(line.get(1).toString()) >= fromX && Integer.parseInt(line.get(1).toString()) <= toX) {
                System.out.println(line);
            }
            line = CSVFileRWUtil.fromCSVLinetoArray(cSVFileRWUtil.readLine());
        }
        return null;
    }

    /**
     *
     * @param fromX 开始列数
     * @param fromY 开始行数
     * @param toX 结束列数
     * @param toY 结束行数
     * @return
     * @throws Exception
     */
    public String readLine(int fromX, int fromY, int toX, int toY, String type) throws Exception {
        List line = CSVFileRWUtil.fromCSVLinetoArray(cSVFileRWUtil.readLine());
        while (!line.isEmpty()) {
            if (Integer.parseInt(line.get(0).toString()) >= fromY && Integer.parseInt(line.get(0).toString()) <= toY
                    && Integer.parseInt(line.get(1).toString()) >= fromX && Integer.parseInt(line.get(1).toString()) <= toX) {
//                System.out.println(line);
                System.out.println(line + "," + type);
                
                fileWriter.addNewLineToFileName("sample", CSVFileRWUtil.toCSVLine(line) + "," + type);
            }
            line = CSVFileRWUtil.fromCSVLinetoArray(cSVFileRWUtil.readLine());
        }
        return null;
    }

    public void writeToFile(String name, String type) throws FileNotFoundException {
        fileWriter.addNewLineToFileName("sample", "type");
    }

    public static void main(String[] args) throws Exception {
//        IMGDMFileUtil i1 = new IMGDMFileUtil("C:\\Users\\Administrator\\Desktop\\基于决策树c45的HJ影像海岸带地物分类规则挖掘\\MapData.txt");
//        i1.readLine(402, 33, 511, 115);
//        //绿
//        i1.readLine(402, 33, 511, 115, "1");
        //蓝
//        IMGDMFileUtil i2 = new IMGDMFileUtil("C:\\Users\\Administrator\\Desktop\\基于决策树c45的HJ影像海岸带地物分类规则挖掘\\MapData.txt");
//        i2.readLine(24, 339, 74, 442,"2");
//        i2.readLine(24, 339, 74, 442);
//        //红
        IMGDMFileUtil i3 = new IMGDMFileUtil("C:\\Users\\Administrator\\Desktop\\基于决策树c45的HJ影像海岸带地物分类规则挖掘\\MapData.txt");
        i3.readLine(662, 519, 820, 653,"3");
    }
}
