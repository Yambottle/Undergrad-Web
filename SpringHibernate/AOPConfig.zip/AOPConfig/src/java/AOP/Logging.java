/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AOP;

/**
 *
 * @author NIIT
 */
public class Logging {
    public void beforeAdvice(){
        System.out.println("Set up");
    }
    
    public void afterAdvice(){
        System.out.println("Created");
    }
    
    public void afterReturningAdvice(Object retVal){
        System.out.println("Returning"+retVal.toString());
    }
    
    public void afterThrowingAdvice(IllegalAccessException iae){
        System.out.println(iae.toString());
    }
}
