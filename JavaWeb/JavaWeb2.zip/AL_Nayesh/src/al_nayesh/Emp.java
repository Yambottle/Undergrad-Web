
package al_nayesh;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Emp extends javax.swing.JFrame {

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    public void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();//empid
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();//empname
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();//empgender
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();//emppos
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();//phone
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();//Proid
        jLabel17 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();//proname
        jLabel18 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();//proprice
        jLabel19 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();//prototal
        jLabel20 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();//informa
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();//sale,date,total
        jButton9 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();//day
        jLabel15 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();//month

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Al-Nayesh Mart:Employee");
        setVisible(true);
        setBounds(500, 200, 312, 296);
        
        Toolkit kit =Toolkit.getDefaultToolkit();
        Image image;
        image=kit.getDefaultToolkit().getImage("D:\\Documents\\NetBeansProjects\\AL_Nayesh\\src\\al_nayesh\\1_副本.png");
        setIconImage(image);
        
        addWindowListener(new java.awt.event.WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e) {
                try{
                Connect con =new Connect();
                con.stmt.execute("update logininformation set logout=getdate() where logid='"+logid+"'");
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, "Logout Time Does't Log.","Warning Message",JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        jTabbedPane1.setName("Inventory Management"); // NOI18N

        jLabel1.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel1.setText("Employee Information：");

        jLabel2.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel2.setText("ID:");

        jLabel3.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel3.setText("Name:");

        jLabel4.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel4.setText("Gender:");

        jLabel5.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel5.setText("Phone Number:");

        jLabel6.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel6.setText("Position:");

        jButton1.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField4))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 48, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton1)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Employee Management", jPanel1);

        jLabel12.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel12.setText("Inventory Information：");

        jLabel16.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel16.setText("Pro_ID:");

        jLabel17.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel17.setText("Name:");

        jLabel18.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel18.setText("Price:");

        jLabel19.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel19.setText("Total:");

        jLabel20.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel20.setText("Pro_Information:");

        jButton12.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton12.setText("Search");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane6.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton12)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel20)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addComponent(jLabel12)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel19)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel18)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextField13))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel16)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel17)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Inventory Management", jPanel2);

        jLabel13.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        jLabel13.setText("Sales Information:");

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},{null, null},{null, null},{null, null},{null, null},
                {null, null},{null, null},{null, null},{null, null},{null, null},
                {null, null},{null, null},{null, null},{null, null},{null, null},
                {null, null},{null, null},{null, null},{null, null},{null, null},
                {null, null},{null, null},{null, null},{null, null},{null, null},
                {null, null},{null, null},{null, null},{null, null},{null, null}
            },
            new String [] {
                "Date", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jButton9.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        jButton9.setText("Search");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }

            
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Just Month", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        jLabel15.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel15.setText("Day:");

        jLabel21.setFont(new java.awt.Font("宋体", 0, 14)); // NOI18N
        jLabel21.setText("Month:");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Jan", "Feb", "Mar", "Apri", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton9)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel15)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel21)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton9)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Sales Data", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("Inventory Management");

        pack();
    }// </editor-fold>                        

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {  
         try{
         Connect con =new Connect();
         String Pro_Id =jTextField11.getText();
         ResultSet rs=con.stmt.executeQuery("select * from Inventory where invid ='"+Pro_Id+"'");
         rs.next();
         String Name=rs.getString("Goodsname");
         String Price=rs.getString("price");
         String Total=rs.getString("num");
         String Pro_Information=rs.getString("information");
         jTextField12.setText(Name);
         jTextField13.setText(Price);
         jTextField14.setText(Total);
         jTextArea1.setText(Pro_Information);
         }catch(Exception e){
             JOptionPane.showMessageDialog(null, "Enter Pro_ID.","Warning Message",JOptionPane.WARNING_MESSAGE);
         } 
    }  
     private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
        int month=0;
        try {
            if(jComboBox1.getSelectedItem().toString().equals("Just Month")){
                if(jComboBox2.getSelectedItem().toString().equals("Jan")){
                    month=1;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Feb")){
                    month=2;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Mar")){
                    month=3;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Apri")){
                    month=4;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("May")){
                    month=5;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("June")){
                    month=6;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("July")){
                    month=7;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Aug")){
                    month=8;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Sept")){
                    month=9;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Oct")){
                    month=10;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Nov")){
                    month=11;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Dec")){
                    month=12;
                }
                Connect con =new Connect();
                ResultSet rsmon =con.stmt.executeQuery("select [date] from Salesdata");
                int row=0 ;
                while(rsmon.next()){
                    ResultSet rs=con.stmt.executeQuery("select empid,[date],totalsell from Salesdata where empid='"+empid+"' and "
                +"datepart(mm,'"+rsmon.getString("date")+"')="+month);
                    while(rs.next()){
                        jTable4.setValueAt(rs.getString("date"), row, 0);
                        jTable4.setValueAt(rs.getString("totalsell"), row, 1);
                        row++;
                    }
                }
            }else{
                if(jComboBox2.getSelectedItem().toString().equals("Jan")){
                    month=1;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Feb")){
                    month=2;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Mar")){
                    month=3;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Apri")){
                    month=4;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("May")){
                    month=5;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("June")){
                    month=6;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("July")){
                    month=7;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Aug")){
                    month=8;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Sept")){
                    month=9;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Oct")){
                    month=10;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Nov")){
                    month=11;
                }
                else if(jComboBox2.getSelectedItem().toString().equals("Dec")){
                    month=12;
                }
                Connect con =new Connect();
                ResultSet rs =con.stmt.executeQuery("select empid,[date],totalsell from Salesdata where empid='"+empid+"'");  
                int row=0 ;
                while(rs.next()){
                jTable4.setValueAt(rs.getString("date"), row, 0);
                jTable4.setValueAt(rs.getString("totalsell"), row, 1);
                row++;
                }
                //将totalnum改为totalsell
            }
        } catch (Exception ex) {
            //no dialog
        }    
    } 
      private void jButton1ActionPerformed(java.awt.event.ActionEvent evt){        
         try{
         Connect con =new Connect();
         String id =jTextField1.getText();
         ResultSet rs=con.stmt.executeQuery("select * from Employee where empid ='"+id+"'");
         rs.next();
         String Name=rs.getString("name");
         String Gender=rs.getString("gender");
         String Position=rs.getString("pos");
         String PhoneNumber=rs.getString("phone");
         jTextField2.setText(Name);
         jTextField3.setText(Gender);
         jTextField4.setText(Position);
         jTextField5.setText(PhoneNumber);
         }catch(Exception e){
             JOptionPane.showMessageDialog(null, "Please Enter Emp_ID.","Warning Message",JOptionPane.WARNING_MESSAGE);
         }
 }
    public void get(String id){
        empid=id;
    }
    public void getlog(String id){
        logid=id;
    }
    // Variables declaration - do not modify   
    String empid;
    String logid;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration                   
}