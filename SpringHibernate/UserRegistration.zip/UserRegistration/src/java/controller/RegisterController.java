/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import service.RegisterService;
import service.User;

@Controller
@RequestMapping(value="/register.htm")

public class RegisterController {

    private RegisterService registerService;

    @RequestMapping(method=RequestMethod.GET)
    public String showView(ModelMap model)
  {
    User u = new User();
    model.addAttribute("CUSTOMER", u);
    return "register";
  }
    @RequestMapping(method=RequestMethod.POST)
    public String processForm(@ModelAttribute(value="CUSTOMER") User user,ModelMap model)
    {
        model.addAttribute("welcomeMessage",registerService.displayMessage());
        return "success";
    }

    public void setRegisterService(RegisterService registerService) {
        this.registerService = registerService;
    }
}
