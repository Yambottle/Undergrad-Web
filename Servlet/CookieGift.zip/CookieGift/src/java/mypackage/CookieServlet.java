/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author RGP™
 */
public class CookieServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        boolean cookieFound = false;
		Cookie myCookie = null;
		/* Retrieve the cookies into a cookie array */
		Cookie[] cookieset = request.getCookies();
		/* Set the content type */
		response.setContentType("text/html");
		/* Retrieve a reference to PrintWriter object */
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("<BODY>");
		
		/* Check if the cookieset is empty or not */
		if (cookieset != null)
		{
			/* Iterate through all the cookies int the cookieset array */
			for (int i = 0; i<cookieset.length; i++)
			{
				/* Compare the name of the cookies in the cookieset array with "logincount" */
				if (cookieset[i].getName().equals("logincount"))	
				{
					/* Set the cookieFound boolean variable to true */
					cookieFound = true;
					/* Store the reference of the found cookie in the myCookie */
					myCookie = cookieset[i];
				}
			}
		}
		/* Check if the cookie is found */
		if (cookieFound)
		{
			/* Retrieve the value of the cookie and parse it to int data type */
			int temp=Integer.parseInt(myCookie.getValue());
			/* Iterate the value */
			temp++;
			/* Check if the value is equal to 5 */
			if (temp == 5)
			/* Display the greeting message */
			out.println("Congratulations!!!!!!!!!!!!!!!!!!!, a gift is awaiting you");
			/* Display the number of times the end user have visited the site */
			out.println("The number of times you have logged in is : " + String.valueOf(temp));
			/* Set the value of the cookie */
			myCookie.setValue(String.valueOf(temp));
			int age = 60*60*24*30; 
			
			/*Set the maximum age of the cookie to one month */
			myCookie.setMaxAge(age);
			/* Add the cookie to myCookie object */
			response.addCookie(myCookie);
			/* Set the cookieFound boolean variable to false. */
			cookieFound = false;
		}			
		else
		{
			/* Set the value of the temp variable to 1 */
			int temp=1;
			out.println("This is the first time you have logged on to the server");
			/* Create a new cookie */
			myCookie=new Cookie("logincount",String.valueOf(temp));
			int age=60*60*24*30;
			/* Set the maximum age of the cookie to one month */
			myCookie.setMaxAge(age);
			/* Add the cookie to myCookie object */
			response.addCookie(myCookie);
		} 
		out.println("</BODY>");
		out.println("</HTML>");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
