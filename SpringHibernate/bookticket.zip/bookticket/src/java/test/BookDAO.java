/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author user
 */
public class BookDAO implements BookService{

    boolean b = true ;
    SessionFactory sessionFactory ;
    
    public BookDAO(){
        Configuration configuration = new Configuration().configure();
    }
    
    @Override
    @Transactional(propagation = Propagation.REQUIRED,readOnly = false,isolation = Isolation.DEFAULT)
    public String bookTiket(Booktiket bt) {
        
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        
        String id = bt.getId();
        Query query = session.createQuery("from test.Booktiket");
        List<Booktiket> books = query.list();
        for(Iterator it = books.iterator();it.hasNext();){
            Booktiket bth = (Booktiket) it.next();
            if(bth.getId().equals(id)){
                b=false;
            }
            if(b==false){
                return "error";
            }else{
                session.save(bt);
                tx.commit();
                return "Success";
            }
        }
        return "";
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    
}
