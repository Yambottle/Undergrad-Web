/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import employee.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import service.Service;

/**
 *
 * @author NIIT
 */
@Controller 
@RequestMapping(value = "/data.htm")
public class HelloController {
    
    private Service service ;
    
    @RequestMapping(method = RequestMethod.GET)
    public String showView(ModelMap model){
        Employee emp = new Employee();
        model.addAttribute("employee", emp);
        return "data";
    }
    
    @RequestMapping(method = RequestMethod.POST)
    public String processForm(@ModelAttribute(value = "employee") Employee emp ,ModelMap model ){
        model.addAttribute("message", service.sayHello(emp.getEname()));
        return "success";
    }

    public void setService(Service service) {
        this.service = service;
    }
    
    
}
