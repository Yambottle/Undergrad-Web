package university;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class BeanDAO {
private SessionFactory sessionFactory;
    public void setSessionFactory(SessionFactory sessionFactory) {
     this.sessionFactory = sessionFactory;
 }
 public BeanDAO() {
 Configuration configuration = new Configuration().configure();
  }

public List getStudent()
 {
       List<Student> students=null;
       try
        {
           Session session = sessionFactory.openSession();
           org.hibernate.Transaction tx = session.beginTransaction();
            Query q = session.createQuery ("from university.Student");
            students = (List<Student>) q.list();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return students;
  }
}
