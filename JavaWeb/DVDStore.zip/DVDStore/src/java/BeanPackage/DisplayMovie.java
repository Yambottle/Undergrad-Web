/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BeanPackage;

import Hibernate.Movie;
import java.io.Serializable;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Administrator
 */
@ManagedBean
@SessionScoped
public class DisplayMovie {

    /**
     * Creates a new instance of DisplayMovie
     */
     private int id;
     private String mname;
     private String pic;
     private String category;
     private String actor;
     private String actress;
     private String descirbe;
     private Serializable mtime;
     private Integer price;
     private List<Movie> movieList;
    
    public DisplayMovie() {
    }
    
    public int getId() {
        return this.id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    public String getMname() {
        return this.mname;
    }
    
    public void setMname(String mname) {
        this.mname = mname;
    }
    public String getPic() {
        return this.pic;
    }
    
    public void setPic(String pic) {
        this.pic = pic;
    }
    public String getCategory() {
        return this.category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    public String getActor() {
        return this.actor;
    }
    
    public void setActor(String actor) {
        this.actor = actor;
    }
    public String getActress() {
        return this.actress;
    }
    
    public void setActress(String actress) {
        this.actress = actress;
    }
    public String getDescirbe() {
        return this.descirbe;
    }
    
    public void setDescirbe(String descirbe) {
        this.descirbe = descirbe;
    }
    public Serializable getMtime() {
        return this.mtime;
    }
    
    public void setMtime(Serializable mtime) {
        this.mtime = mtime;
    }
    public Integer getPrice() {
        return this.price;
    }
    
    public void setPrice(Integer price) {
        this.price = price;
    }
    
    public List<Movie> getMovie() {
        return movieList;
    }

    public void setMovie(List<Movie> movieList) {
        this.movieList = movieList;
    }
    
    public void showMovie(){
        HelperBean helper = new HelperBean();
        this.setMovie(helper.getMovie());
    }
    
    public void chooseMovie(String id){
        HelperBean helper = new HelperBean();
        Movie movie = helper.getChooseMovie(id).get(0);
        setId(movie.getId());
        setMname(movie.getMname());
        setCategory(movie.getCategory());
        setActor(movie.getActor());
        setActress(movie.getActress());
        setMtime(movie.getMtime());
        setPrice(movie.getPrice());
    }
    
    public void showMovieByABC(String capital){
        HelperBean helper = new HelperBean();
        this.setMovie(helper.getMovieByABC(capital));
    }
    
    public void showMovieByCate(String category){
        HelperBean helper = new HelperBean();
        this.setMovie(helper.getMovieByCate(category));
    }
    
}
