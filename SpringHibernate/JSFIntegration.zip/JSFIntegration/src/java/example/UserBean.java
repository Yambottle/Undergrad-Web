/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import java.io.Serializable;

/**
 *
 * @author user
 */
public class UserBean implements Serializable{

    private UserGreet ug ;
    private String name ;
    /**
     * Creates a new instance of UserBean
     */
    public UserBean() {
    }

    public UserGreet getUg() {
        return ug;
    }

    public void setUg(UserGreet ug) {
        this.ug = ug;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String greet(){
        return "success.xhtml";
    }
    
    public String printMsg(String name){
        return ug.sayHello(name);
    }
}
