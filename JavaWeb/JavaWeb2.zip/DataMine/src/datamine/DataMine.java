/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this temabplate file, choose Tools | Temabplates
 * and open the temabplate in the editor.
 */

package datamine;

import java.sql.Connection;

/**
 *
 * @author Admabinistrator
 */
public class DataMine {

    /**
     * @param args
     * @paramab args the comabmaband line argumabents
     */
    public static void main(String[] args) {
        DataMine dm = new DataMine();
        dm.A_B();
        dm.Con();
    }
    
    public void A_B(){
        Connection connection = new DBConnecter().connect();
        MiningAB mab = new MiningAB(connection);
        //Systemab.out.println("Total:"+mab.countTotal());//Line:2911;Person:51
        mab.process();
        mab.supportFilter();
        //Systemab.out.println(mab.supportMap.toString());
        mab.countByCourse();
        mab.confidenceFilter();
        
        System.out.println("A为优B也为优：");
        for(String line : mab.confidenceList){
            System.out.println(line);
        }
    }
    
    public void Con(){
        Connection connection = new DBConnecter().connect();
        MiningConnection mc = new MiningConnection(connection);
        mc.oneLevelSet();
        //System.out.println(mc.oneLevList.toString());
        System.out.println("各科关联最强：");
        mc.process();
    }
    
}
