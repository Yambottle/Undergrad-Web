/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package datamine;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author Administrator
 */
public class MiningAB {
    
    Connection connection;
    Map<String,Integer> supportFlagMap, supportMap, countByCourseMap ;
    ArrayList<String> confidenceList ;
    Float A_Grade = 90.0f;
    int minSupport = 7;
    double minConfidence = 0.5;
    
    
    public MiningAB(Connection connection){
        this.connection = connection;
        supportFlagMap = new HashMap<>();
        supportMap = new HashMap<>();
        countByCourseMap = new HashMap<>();
        confidenceList = new ArrayList<>();
    }
    
    public int countTotal(){
        int total=0;
        
        try {
            String stuIDSql = "select distinct stuID from Sheet ";
            ResultSet stuIDRS;
            stuIDRS = search(stuIDSql);//stuID
            while(stuIDRS.next()){
                String oneInfoSql = "select stuID,courseID,courseName,max(grades) from Sheet where stuID ="+stuIDRS.getString(1)+" group by stuID,courseID,courseName";
                ResultSet oneInfoRS;
                oneInfoRS = search(oneInfoSql);
                while(oneInfoRS.next()){
                    total++;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return total;
    }
    
    public ResultSet search(String sql){
        
        Statement stat;
        ResultSet rs=null;
        try {
            stat =  connection.createStatement();
            rs = stat.executeQuery(sql);//"select * from DataMine.dbo.Sheet"
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rs;
    }
    
    public void insertIntoMap(String onetwo ,String twoone){
        if(supportFlagMap.get(onetwo) != null){
            supportFlagMap.put(onetwo, supportFlagMap.get(onetwo)+1);
        }else if(supportFlagMap.get(twoone) != null){
            supportFlagMap.put(twoone, supportFlagMap.get(twoone)+1);
        }else{
            supportFlagMap.put(onetwo, 1);
        }
    }
    
    public void process(){
        
        try {
            String stuIDSql = "select distinct stuID from Sheet ";
            ResultSet stuIDRS;
            stuIDRS = search(stuIDSql);//stuID
            while(stuIDRS.next()){
                String oneInfoSql = "select stuID,courseID,courseName,max(grades) from Sheet where stuID ="+stuIDRS.getString(1)+" group by stuID,courseID,courseName";
                ResultSet oneInfoRS;
                oneInfoRS = search(oneInfoSql);//one
                while(oneInfoRS.next()){
                    String oneInfoAgainSql = "select stuID,courseID,courseName,max(grades) from Sheet where stuID ="+stuIDRS.getString(1)+" group by stuID,courseID,courseName";
                    ResultSet oneInfoAgainRS ;
                    oneInfoAgainRS = search(oneInfoAgainSql);
                    oneInfoAgainRS.next();//oneAgain
                    while(oneInfoAgainRS.next()){
                        if(oneInfoRS.getFloat(4) >= A_Grade && oneInfoAgainRS.getFloat(4) >= A_Grade){
                            insertIntoMap(oneInfoRS.getString(2)+","+oneInfoAgainRS.getString(2),
                                    oneInfoAgainRS.getString(2)+","+oneInfoRS.getString(2));
                            //System.out.println("1");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void supportFilter(){
        for(Map.Entry<String,Integer> entry : supportFlagMap.entrySet()){
            if(entry.getValue() > minSupport){
                supportMap.put(entry.getKey(),entry.getValue());
            }
        }
    }
    
    public void countByCourse(){
        try {
            String countByCourseSql = "select courseID,count(distinct stuID) from Sheet group by courseID";
            ResultSet countByCourseRS;
            countByCourseRS = search(countByCourseSql);
            while(countByCourseRS.next()){
                countByCourseMap.put(countByCourseRS.getString(1), countByCourseRS.getInt(2));
            }
        } catch (SQLException ex) {
             ex.printStackTrace();
        }
    }
    
    public void confidenceFilter(){
        for(Map.Entry<String , Integer> supportEntry :supportMap.entrySet()){
            String course[] = new String[2];
            course = supportEntry.getKey().toString().split(",");
            if(course[0].equals(course[1])){
                continue;
            }
            int fz = supportEntry.getValue();
            for(Map.Entry<String , Integer> countEntry :countByCourseMap.entrySet()){
                if(course[0].equals(countEntry.getKey())){
                    int fm = countEntry.getValue();
                    if( (double)(fz*1.0/fm) > minConfidence){
                        confidenceList.add(course[0]+"->"+course[1]);
                    }
                }
                if(course[1].equals(countEntry.getKey())){
                    int fm2 = countEntry.getValue();
                    if( (double)(fz*1.0/fm2) > minConfidence){
                        confidenceList.add(course[1]+"->"+course[0]);
                        }
                 }
            }
        }
    }
}
