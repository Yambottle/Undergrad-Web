/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author NIIT
 */
public class Test {

    public static void main(String[] args) {
        ApplicationContext ac = new ClassPathXmlApplicationContext("newpackage/Spring-Config.xml");
        Football f =(Football)ac.getBean("KaKa");
        f.play();
        Football f2 =(Football)ac.getBean("Forlan");
        f2.play();
    }
    
}
