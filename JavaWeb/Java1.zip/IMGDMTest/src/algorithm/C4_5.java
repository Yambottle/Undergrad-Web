/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class C4_5 {

//    /**
//     * 计算两个值的熵
//     *
//     * @param listArray
//     * @return
//     */
//    public static double I(List listArray) {
//        double all = 0.0; //计算总数
//        for (Object i : listArray) {
//            if ((int) i == 0) {
//                return 0.0;
//            } else {
//                all += (int) i * 1.0;
//            }
//        }
//        double result = 0.0;
//        for (Object i : listArray) {
//            result += -((int) i / all) * log((int) i / all, 2);
//        }
//        return result;
//    }

    /**
     * 计算两个值的熵
     *
     * @param x
     * @param y
     * @return
     */
    public static double I(int x, int y) {
        if (x != 0 && y != 0) {
            double all = x * 1.0 + y * 1.0;
            return (-(x / all) * log(x / all, 2) - (y / all) * log(y / all, 2));
        } else {
            return 0.0;
        }
    }

    /**
     * 换底公式
     *
     * @param a
     * @param base
     * @return
     */
    public static double log(double a, int base) {
//        System.out.println(Math.log(a) / Math.log(base));
        return Math.log(a) / Math.log(base);
    }

    /**
     * 计算期望
     *
     * @param data list
     * @return
     */
    public static double Ex(List<Two> data) {
        double ex = 0.0;
        int all = 0;
        for (Two two : data) {
            all += two.a + two.b;
        }
        for (Two two : data) {
//            System.out.println((double) (two.a + two.b) / (double) all * I(two.a, two.b));
            ex += (double) (two.a + two.b) / (double) all * I(two.a, two.b);
//            System.out.println(I(integers[0], integers[1]));
        }
//        System.out.println(ex);
        return ex;
    }

    public static double Gain(int x, int y,List<Two> data) {
        return I(x,y)-Ex(data);
    }
    
    public static double Split_info(int x, int y) {
        return I(x,y);
    }
    
    /**
     * 信息增益率
     * @param x ，分割结果集，用于计算gain
     * @param y 分割结果集，用于计算gain
     * @param data 分割结果集，用于计算gain
     * @param m 分割属性集，计算Split_info
     * @param n 分割属性集，计算Split_info
     * @return 
     */
    public static double Gain_ratio(int x, int y, List<Two> data, int m, int n) {
        return Gain(x, y, data) / Split_info(m,n);
    }
    
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add(new Two(0, 1));
        list.add(new Two(2, 2));
//        list.add(new Two(3,2));
////        
//        C4_5 d = new C4_5();
        System.out.println(Gain_ratio(2, 3, list, 1, 4));
          
    }
}
