/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AOP;

/**
 *
 * @author user
 */
public class ValidateUser {
    
    public static String msg1 ;
    public static String msg2 ;

    public ValidateUser() {
    }
    
    public void validateUser(String user){
        if(user.equals("John")){
            msg1 ="User Authenticated.";
        }else{
            msg1="Invalid User.";
        }
    }
    
    public void awardGift(){
        if(msg1.equals("User Authenticated.")){
            msg2="You got a gift.";
        }else{
            msg2="You don't have any gift.";
        }
    }
}
