/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import test.BookService;
import test.Booktiket;

/**
 *
 * @author user
 */
@ManagedBean
@RequestScoped
public class Bean {

    String id ; 
    String name;
    int ticket;
    
    public Bean() {
    }

    public String submit(){
        Booktiket bt = new Booktiket();
        ApplicationContext ac = new ClassPathXmlApplicationContext("test/Spring-Hibernate.xml");
        BookService helper = (BookService) ac.getBean("bookDao");
        bt.setId(getId());
        bt.setName(getName());
        bt.setTicket(getTicket());
        String msg = helper.bookTiket(bt);
       
        return msg;
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTicket() {
        return ticket;
    }

    public void setTicket(int ticket) {
        this.ticket = ticket;
    }
    
    
}
