package newpackage;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class ErrorServlet extends HttpServlet
{
    String EXC ="javax.servlet.error.exception";
    String MSG="javax.servlet.error.message";
    String ST ="javax.servlet.error.status_code";
    String SN ="javax.servlet.error.servlet_name";
    String RURI ="javax.servlet.error.request_uri";
    
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, 
        IOException
  	{
		ServletContext sc = getServletContext();
		PrintWriter pw = response.getWriter();
		
                Exception exc = (Exception)request.getAttribute(EXC);
                String msg = (String)request.getAttribute(MSG);
                Integer st_cd =(Integer)request.getAttribute(ST);
                String sname =(String)request.getAttribute(SN);
                String ruri =(String)request.getAttribute(RURI);
                

                pw.println("<HTML>");
		pw.println("<BODY>");
		pw.println("<HR>");
                pw.println("<H1>Sorry, an error has occurred that has prevented the server from servicing your request.</H1>");
		pw.println("<FONT SIZE = 5>");
		pw.println("<TABLE BORDER=2 BGCOLOR=LIGHTBLUE ALIGN = CENTER>");
		pw.println("<TR>");
		pw.println("<TD><B> Status Code : </B></TD><TD>" + st_cd + " </TD>");
		pw.println("</TR>");
		pw.println("<TR>");
                pw.println("<TD><B> Type of Exception :</B></TD><TD>" + exc.getClass() + " </TD>");
		pw.println("</TR>");
		pw.println("<TR>");
                pw.println("<TD><B> Message Description  : </B></TD><TD>" +msg  + " </TD>");
                pw.println("</TR>");
                pw.println("<TD><B> Servlet Name  : </B></TD><TD>" + sname + " </TD>");
		String str = exc.toString()+st_cd+msg;
		sc.log("Exception occurred"+str);
		pw.println("</TR>");
                pw.println("<TR>");
                pw.println("<TD><B>REQUEST URI  :</B></TD><TD>" + ruri + "</TD></HR>" );
                pw.println("</TR>");
		pw.println("</TABLE>");
                pw.println("</FONT>");
		pw.println("<HR>");
		pw.println("<HR>");
		pw.println("<CENTER><H1>Please try again...</H1></CENTER>");
		pw.println("</BODY>");
		pw.println("</HTML>");
	}



    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
