/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String role = request.getParameter("rd");
            String id = request.getParameter("id");
            String pwd = request.getParameter("pwd");
            if(role == null ||role.equals("")||id==null||id.equals("")||pwd==null||pwd.equals("")){
                role=(String)request.getAttribute("role");
                id=(String)request.getAttribute("id");
                pwd=(String)request.getAttribute("pwd");
            }
            
            Connect con = new Connect();
            ResultSet rs=null;
            
            if(role.equals("S")){
                rs=con.stmt.executeQuery("select pwd from student where regno ='" +id+"'");
                rs.next();
                if(rs.getString(1).equals(pwd)){
                    con.con.close();
                    //Student页面
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet Regist</title>");            
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<form name=\"Student\" action=\"post\">");
                    out.println("<select id=\"selectOption\">");
                    out.println("<option value=\"JavaProgramming\" name=\"select\">Java Programming</option>");
                    out.println("<option value=\"HTML-5\" name=\"select\">HTML-5</option>");
                    out.println("<option value=\"JSP-Servlet\" name=\"select\">JSP-Servlet</option>");
                    out.println("<option value=\"Hibernate\" name=\"select\">Hibernate</option>");
                    out.println("<option value=\"WebServices\" name=\"select\">Web Services</option>");
                    out.println("</select>");            
                    out.println("</form>");
                    out.println("</body>");
                    out.println("</html>");
                }else{
                    out.println("Your password is incorrect or your ID is inexistent.<br>");
                    out.println("<a href=\"index.html\">Go Back...</a>");
                }
            }else{
                rs=con.stmt.executeQuery("select pwd from teacher where tid ='" +id+"'");
                rs.next();
                if(rs.getString(1).equals(pwd)){
                    con.con.close();
                    //Admin页面
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet Regist</title>");            
                    out.println("</head>");
                    out.println("<body>");
                    out.println("</body>");
                    out.println("</html>");
                }else{
                    out.println("Your password is incorrect or your ID is inexistent.<br>");
                    out.println("<a href=\"index.html\">Go Back...</a>");
                } 
            }
        } catch (SQLException ex) {
            ex.toString();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
