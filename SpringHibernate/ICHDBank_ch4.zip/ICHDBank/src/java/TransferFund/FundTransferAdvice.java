/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TransferFund;

import java.lang.reflect.Method;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

/**
 *
 * @author maple
 */
public class FundTransferAdvice implements MethodBeforeAdvice, AfterReturningAdvice, ThrowsAdvice{

    private ValidatingFundTransfer validatingFundTransfer;
    @Override
    public void before(Method method, Object[] os, Object target) throws Throwable {
        validatingFundTransfer.validatePassword(os[0].toString());
        System.out.println(os[3]);
        validatingFundTransfer.validateAmount(Double.parseDouble(os[2].toString()), Double.parseDouble(os[3].toString()));
    }

    @Override
    public void afterReturning(Object o, Method method, Object[] os, Object target) throws Throwable {
        validatingFundTransfer.updateBalance(Double.parseDouble(os[2].toString()), Double.parseDouble(os[3].toString()));
    }
    public void afterThrowing(Throwable throwable){
        
    }

    public void setValidatingFundTransfer(ValidatingFundTransfer validatingFundTransfer) {
        this.validatingFundTransfer = validatingFundTransfer;
    }
    
}
