
package createtrans;
import java.sql.*;

public class CreateTrans {

    public static void main(String[] args) {
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            Connection con =
            DriverManager.getConnection(
                    "jdbc:sqlserver://localhost;"
                            + "databasename=library;"
                            + "user=sa;password=niit");
            con.setAutoCommit(false);
            
            PreparedStatement ps =con.prepareStatement(
                    "insert into Publishers(pub_id,pub_name)"
                            + "values(?,?)");
            ps.setString(1, "P006");
            ps.setString(2, "MainStream Publishing");
            int firstctr =ps.executeUpdate();
            System.out.println("First Row Inserted but not committed.");
            
            PreparedStatement ps2 =con.prepareStatement(
                    "insert into Publishers(pub_id,pub_name)"
                            + "values(?,?)");
            ps2.setString(1, "P007");
            ps2.setString(2, "MainStream Publishing");
            int secondctr =ps2.executeUpdate();
            System.out.println("Second Row Inserted but not committed.");
            
            con.commit();
            System.out.println("Transaction Committed,"
                    + "Please check table for data.");
            
        }catch(Exception e){
            System.out.println("Error is: "+e.getMessage());
        }
    }
    
}
