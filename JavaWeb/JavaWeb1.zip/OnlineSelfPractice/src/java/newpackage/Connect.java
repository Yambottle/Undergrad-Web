
package newpackage;
import java.sql.*;

public class Connect {
    Statement stmt;
    Connection con;
    public Connect(){
        try{Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=webdb;user=webadmin;password=admin");
            this.stmt=con.createStatement();
        }catch(Exception e){System.out.println(e.toString());}
    }
    public PreparedStatement set(String s){
        PreparedStatement stat=null;
    	try {
            stat=con.prepareStatement(s);
	}catch (SQLException e) {e.printStackTrace();}
            return stat;
    }  
}