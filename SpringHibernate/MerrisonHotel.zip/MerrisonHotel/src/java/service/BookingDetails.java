/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package service;

public class BookingDetails {
    private String bookingId;
    private String customerFName;
    private String customerLName;
    private String address;
    private String phone;
    private String checkInDay;
    private String checkInMonth;
    private String checkInYear;

    private String checkOutDay;
    private String checkOutMonth;
    private String checkOutYear;
    private String roomType;
    private int noOfRooms;
    private int noofChildren;
    private int noOfAdults;

    public BookingDetails(){

    }

    /**
     * @return the bookingId
     */
    public String getBookingId() {
        return bookingId;
    }

    /**
     * @param bookingId the bookingId to set
     */
    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    /**
     * @return the customerFName
     */
    public String getCustomerFName() {
        return customerFName;
    }

    /**
     * @param customerFName the customerFName to set
     */
    public void setCustomerFName(String customerFName) {
        this.customerFName = customerFName;
    }

    /**
     * @return the customerLName
     */
    public String getCustomerLName() {
        return customerLName;
    }

    /**
     * @param customerLName the customerLName to set
     */
    public void setCustomerLName(String customerLName) {
        this.customerLName = customerLName;
    }

   

    /**
     * @return the roomType
     */
    public String getRoomType() {
        return roomType;
    }

    /**
     * @param roomType the roomType to set
     */
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    /**
     * @return the noOfRooms
     */
    public int getNoOfRooms() {
        return noOfRooms;
    }

    /**
     * @param noOfRooms the noOfRooms to set
     */
    public void setNoOfRooms(int noOfRooms) {
        this.noOfRooms = noOfRooms;
    }

    /**
     * @return the noofChildren
     */
    public int getNoofChildren() {
        return noofChildren;
    }

    /**
     * @param noofChildren the noofChildren to set
     */
    public void setNoofChildren(int noofChildren) {
        this.noofChildren = noofChildren;
    }

    /**
     * @return the noOfAdults
     */
    public int getNoOfAdults() {
        return noOfAdults;
    }

    /**
     * @param noOfAdults the noOfAdults to set
     */
    public void setNoOfAdults(int noOfAdults) {
        this.noOfAdults = noOfAdults;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the checkInDay
     */
    public String getCheckInDay() {
        return checkInDay;
    }

    /**
     * @param checkInDay the checkInDay to set
     */
    public void setCheckInDay(String checkInDay) {
        this.checkInDay = checkInDay;
    }

    /**
     * @return the checkInMonth
     */
    public String getCheckInMonth() {
        return checkInMonth;
    }

    /**
     * @param checkInMonth the checkInMonth to set
     */
    public void setCheckInMonth(String checkInMonth) {
        this.checkInMonth = checkInMonth;
    }

    /**
     * @return the checkInYear
     */
    public String getCheckInYear() {
        return checkInYear;
    }

    /**
     * @param checkInYear the checkInYear to set
     */
    public void setCheckInYear(String checkInYear) {
        this.checkInYear = checkInYear;
    }

    /**
     * @return the checkOutDay
     */
    public String getCheckOutDay() {
        return checkOutDay;
    }

    /**
     * @param checkOutDay the checkOutDay to set
     */
    public void setCheckOutDay(String checkOutDay) {
        this.checkOutDay = checkOutDay;
    }

    /**
     * @return the checkOutMonth
     */
    public String getCheckOutMonth() {
        return checkOutMonth;
    }

    /**
     * @param checkOutMonth the checkOutMonth to set
     */
    public void setCheckOutMonth(String checkOutMonth) {
        this.checkOutMonth = checkOutMonth;
    }

    /**
     * @return the checkOutYear
     */
    public String getCheckOutYear() {
        return checkOutYear;
    }

    /**
     * @param checkOutYear the checkOutYear to set
     */
    public void setCheckOutYear(String checkOutYear) {
        this.checkOutYear = checkOutYear;
    }
    
}
