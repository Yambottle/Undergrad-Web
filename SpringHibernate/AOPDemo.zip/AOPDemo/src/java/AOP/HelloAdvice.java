/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AOP;

import java.lang.reflect.Method;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

/**
 *
 * @author user
 */
public class HelloAdvice implements MethodBeforeAdvice,AfterReturningAdvice{

    private ValidateUser vu ;
    
    @Override
    public void before(Method method, Object[] os, Object o) throws Throwable {
        vu.validateUser((String)os[0]);
    }

    @Override
    public void afterReturning(Object o, Method method, Object[] os, Object o1) throws Throwable {
        vu.awardGift();
    }
    
    public void setVu(ValidateUser vu) {
        this.vu = vu;
    }
}
