/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package 等腰三角形;

/**
 *
 * @author Administrator
 */
public class 等腰三角形 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         int i,j,row;
        for(row=5;row>=1;row--)
        {
          for(i=1;i<=row;i++)
          {System.out.print(" ");
          }
          for(j=1;j<=6-row;j++)
          {System.out.print("* ");
          }
          System.out.println();
        }
    }
    
}
